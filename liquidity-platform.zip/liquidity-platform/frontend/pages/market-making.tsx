import { useState } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Zap, Activity, BarChart2, Clock, Users, Shield, Send } from 'lucide-react';
import Layout from '../components/layout/Layout';

const services = [
  {
    icon: Zap,
    title: 'Ultra-Tight Spreads',
    desc: 'Sub-0.1% spreads across all major pairs. We compete with top-tier CEX market makers.',
    metric: '< 0.05%',
    metricLabel: 'Average Spread',
  },
  {
    icon: BarChart2,
    title: 'Deep Orderbook',
    desc: 'Multi-level orderbook depth providing $10M+ liquidity at every price level.',
    metric: '$10M+',
    metricLabel: 'Per Level',
  },
  {
    icon: Activity,
    title: 'Volume Generation',
    desc: 'Algorithmic trading bots that generate organic-looking volume to improve exchange rankings.',
    metric: '24/7',
    metricLabel: 'Operation',
  },
  {
    icon: Clock,
    title: 'TGE Support',
    desc: 'Specialized launch liquidity for Token Generation Events. Smooth price discovery from day one.',
    metric: 'Day 1',
    metricLabel: 'Ready',
  },
];

const packages = [
  {
    name: 'Starter',
    price: '$8,000/mo',
    liquidity: '$500K',
    pairs: '2 pairs',
    exchanges: '1 exchange',
    features: [
      'Spread management',
      'Basic orderbook depth',
      'Monthly reports',
      'Email support',
    ],
    popular: false,
    color: 'neon',
  },
  {
    name: 'Professional',
    price: '$25,000/mo',
    liquidity: '$2M',
    pairs: '5 pairs',
    exchanges: '3 exchanges',
    features: [
      'Ultra-tight spreads',
      'Deep orderbook management',
      'Volume generation',
      'Weekly reports',
      'Slack support',
      'TGE support',
    ],
    popular: true,
    color: 'gold',
  },
  {
    name: 'Institutional',
    price: 'Custom',
    liquidity: '$20M+',
    pairs: 'Unlimited',
    exchanges: 'All major',
    features: [
      'Full market making suite',
      'Custom strategy development',
      'Real-time dashboard',
      'Dedicated account manager',
      'API integration',
      'Cross-exchange arbitrage',
    ],
    popular: false,
    color: 'neon',
  },
];

const exchanges = [
  'Binance', 'Coinbase', 'OKX', 'Bybit', 'Kraken',
  'Uniswap', 'dYdX', 'GMX', 'Perpetual Protocol', 'Vertex',
];

export default function MarketMaking() {
  const [form, setForm] = useState({
    tokenName: '',
    tokenSymbol: '',
    exchange: '',
    liquidityRequired: '',
    budget: '',
    email: '',
    tge: false,
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setSubmitted(true);
    setLoading(false);
  };

  return (
    <Layout>
      <Head>
        <title>Market Making — LiquidityX</title>
      </Head>

      <div className="py-12 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-16">
          <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">Market Making</div>
          <h1 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
            Institutional market making<br />
            <span className="gradient-text-gold">that moves markets.</span>
          </h1>
          <p className="text-text-muted max-w-xl leading-relaxed">
            We provide professional market making services for projects and institutions. Tight spreads, 
            deep liquidity, and continuous operations across CEX and DEX.
          </p>
        </motion.div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-20">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="stat-card"
            >
              <div className="w-10 h-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center mb-4">
                <s.icon className="w-5 h-5" />
              </div>
              <div className="font-display text-2xl font-700 text-gold mb-1">{s.metric}</div>
              <div className="text-xs text-text-muted mb-3">{s.metricLabel}</div>
              <h3 className="font-600 text-text mb-2">{s.title}</h3>
              <p className="text-sm text-text-muted leading-relaxed">{s.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Exchanges */}
        <div className="mb-20">
          <div className="text-xs text-text-muted uppercase tracking-widest mb-6 text-center">Supported Exchanges</div>
          <div className="flex flex-wrap justify-center gap-3">
            {exchanges.map((ex) => (
              <div key={ex} className="px-4 py-2 bg-surface border border-border rounded-lg text-sm text-text-muted hover:border-gold/30 hover:text-gold transition-all cursor-default">
                {ex}
              </div>
            ))}
          </div>
        </div>

        {/* Packages */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">Pricing</div>
            <h2 className="font-display text-4xl font-700 text-text">
              Choose your <span className="gradient-text-gold">package</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {packages.map((pkg, i) => (
              <motion.div
                key={pkg.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                className={`relative rounded-2xl p-8 border transition-all ${
                  pkg.popular
                    ? 'bg-gold/5 border-gold/30 shadow-gold'
                    : 'bg-surface border-border hover:border-neon/20'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-gold rounded-full text-xs font-700 text-background">
                    Most Popular
                  </div>
                )}
                <div className="mb-6">
                  <div className={`text-sm font-600 uppercase tracking-wider mb-2 ${pkg.popular ? 'text-gold' : 'text-neon'}`}>
                    {pkg.name}
                  </div>
                  <div className="font-display text-3xl font-700 text-text">{pkg.price}</div>
                </div>
                <div className="grid grid-cols-3 gap-3 mb-6 text-center">
                  <div className="bg-surface-2 rounded-lg p-2">
                    <div className={`text-sm font-700 ${pkg.popular ? 'text-gold' : 'text-neon'}`}>{pkg.liquidity}</div>
                    <div className="text-[10px] text-text-muted">Liquidity</div>
                  </div>
                  <div className="bg-surface-2 rounded-lg p-2">
                    <div className={`text-sm font-700 ${pkg.popular ? 'text-gold' : 'text-neon'}`}>{pkg.pairs}</div>
                    <div className="text-[10px] text-text-muted">Pairs</div>
                  </div>
                  <div className="bg-surface-2 rounded-lg p-2">
                    <div className={`text-sm font-700 ${pkg.popular ? 'text-gold' : 'text-neon'}`}>{pkg.exchanges}</div>
                    <div className="text-[10px] text-text-muted">Exchanges</div>
                  </div>
                </div>
                <ul className="space-y-2.5 mb-8">
                  {pkg.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-text-muted">
                      <CheckCircle className={`w-4 h-4 flex-shrink-0 ${pkg.popular ? 'text-gold' : 'text-neon'}`} />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className={`w-full py-3 rounded-xl font-600 text-sm transition-all flex items-center justify-center gap-2 ${
                    pkg.popular
                      ? 'btn-gold'
                      : 'btn-outline'
                  }`}
                >
                  Get Started <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Contact form */}
        <div id="contact-form" className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <div className="text-xs text-neon uppercase tracking-widest font-mono mb-3">Apply Now</div>
            <h2 className="font-display text-4xl font-700 text-text">
              Request <span className="gradient-text-neon">market making</span>
            </h2>
          </div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16 bg-surface border border-neon/20 rounded-2xl"
            >
              <div className="w-16 h-16 rounded-2xl bg-neon/10 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-neon" />
              </div>
              <h3 className="font-display text-2xl font-700 text-text mb-2">Application Received!</h3>
              <p className="text-text-muted max-w-sm mx-auto">
                Our team will review your application and reach out within 24 hours.
              </p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-surface border border-border rounded-2xl p-8 space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Token Name *</label>
                  <input
                    required
                    className="input-field"
                    placeholder="e.g. MyProject"
                    value={form.tokenName}
                    onChange={(e) => setForm({ ...form, tokenName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Token Symbol *</label>
                  <input
                    required
                    className="input-field"
                    placeholder="e.g. MYT"
                    value={form.tokenSymbol}
                    onChange={(e) => setForm({ ...form, tokenSymbol: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Exchange(s) *</label>
                <input
                  required
                  className="input-field"
                  placeholder="e.g. Binance, Uniswap"
                  value={form.exchange}
                  onChange={(e) => setForm({ ...form, exchange: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Liquidity Required *</label>
                  <input
                    required
                    className="input-field"
                    placeholder="e.g. $500,000"
                    value={form.liquidityRequired}
                    onChange={(e) => setForm({ ...form, liquidityRequired: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Monthly Budget *</label>
                  <input
                    required
                    className="input-field"
                    placeholder="e.g. $10,000"
                    value={form.budget}
                    onChange={(e) => setForm({ ...form, budget: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Contact Email *</label>
                <input
                  type="email"
                  required
                  className="input-field"
                  placeholder="your@company.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </div>
              <div className="flex items-center gap-3 p-4 bg-surface-2 rounded-xl">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, tge: !form.tge })}
                  className={`w-5 h-5 rounded flex-shrink-0 border-2 flex items-center justify-center ${
                    form.tge ? 'bg-neon border-neon' : 'border-border'
                  }`}
                >
                  {form.tge && (
                    <svg viewBox="0 0 16 16" fill="none" className="w-3 h-3">
                      <path d="M3 8l3 3 7-7" stroke="#0A0A0A" strokeWidth="2.5" strokeLinecap="round" />
                    </svg>
                  )}
                </button>
                <span className="text-sm text-text-muted">
                  This is for a Token Generation Event (TGE)
                </span>
              </div>
              <div>
                <label className="text-xs text-text-muted uppercase tracking-wider mb-1.5 block">Additional Notes</label>
                <textarea
                  rows={3}
                  className="input-field resize-none"
                  placeholder="Tell us more about your project..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="btn-gold w-full py-3.5 flex items-center justify-center gap-2 text-sm font-700"
              >
                {loading ? (
                  <><div className="loader w-4 h-4" /> Submitting...</>
                ) : (
                  <><Send className="w-4 h-4" /> Submit Application</>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </Layout>
  );
}
