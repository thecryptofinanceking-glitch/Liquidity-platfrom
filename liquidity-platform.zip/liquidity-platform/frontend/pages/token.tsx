import Head from 'next/head';
import { motion } from 'framer-motion';
import { DollarSign, Vote, Star, Zap, Lock, ArrowRight, TrendingUp, Users } from 'lucide-react';
import Layout from '../components/layout/Layout';

const tokenomics = [
  { label: 'Community Rewards', pct: 35, color: '#00FFB2' },
  { label: 'Protocol Treasury', pct: 20, color: '#D4AF37' },
  { label: 'Team & Advisors', pct: 15, color: '#4A9FFF' },
  { label: 'Ecosystem Growth', pct: 15, color: '#FF6B6B' },
  { label: 'Investors', pct: 10, color: '#9B59B6' },
  { label: 'Liquidity', pct: 5, color: '#E67E22' },
];

const stakingTiers = [
  { tier: 'Bronze', min: '1,000 LQX', apy: '35%', features: ['Revenue share', 'Basic governance'], color: '#CD7F32' },
  { tier: 'Silver', min: '10,000 LQX', apy: '52%', features: ['Revenue share', 'Full governance', 'Reduced fees'], color: '#C0C0C0' },
  { tier: 'Gold', min: '50,000 LQX', apy: '67%', features: ['Revenue share', 'Full governance', 'Zero fees', 'Premium pools'], color: '#D4AF37' },
  { tier: 'Platinum', min: '200,000 LQX', apy: '89%', features: ['Max revenue share', 'Proposal rights', 'Private pools', 'API access'], color: '#00FFB2' },
];

export default function Token() {
  return (
    <Layout>
      <Head>
        <title>LQX Token — LiquidityX</title>
      </Head>

      <div className="py-12 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">LQX Token</div>
          <h1 className="font-display text-4xl md:text-6xl font-700 text-text mb-4">
            The <span className="gradient-text-gold">LQX</span> token.<br />
            Real utility. Real value.
          </h1>
          <p className="text-text-muted max-w-xl mx-auto leading-relaxed">
            LQX powers the entire LiquidityX ecosystem. Stake for yield, govern the protocol, 
            and benefit from continuous buyback pressure.
          </p>

          {/* Token metrics */}
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            {[
              { label: 'Token Price', value: '$1.24', change: '+12.3%', up: true },
              { label: 'Market Cap', value: '$9.8M', change: '+8.1%', up: true },
              { label: 'Circulating Supply', value: '7.9M LQX', change: '-0.3% (burned)', up: false },
              { label: 'Staking APY', value: 'Up to 89%', change: 'Variable', up: true },
            ].map((m) => (
              <div key={m.label} className="bg-surface border border-border rounded-xl px-6 py-4 text-center min-w-[160px]">
                <div className="text-xs text-text-muted mb-1">{m.label}</div>
                <div className="font-display font-700 text-xl text-gold">{m.value}</div>
                <div className={`text-xs font-500 mt-0.5 ${m.up ? 'text-neon' : 'text-danger'}`}>{m.change}</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Utility grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
          {[
            { icon: DollarSign, title: 'Revenue Share', desc: '60% of all protocol revenue distributed to LQX stakers weekly in USDC.', badge: '60% of fees', color: 'neon' },
            { icon: Vote, title: 'Governance', desc: 'Vote on protocol upgrades, fee parameters, new pool additions, and treasury allocations.', badge: 'DAO', color: 'gold' },
            { icon: Star, title: 'Premium Pools', desc: 'Access exclusive high-yield pools with 3x higher APY available only to LQX holders.', badge: 'Exclusive', color: 'neon' },
            { icon: Zap, title: 'Fee Reduction', desc: 'Hold LQX to reduce your trading and liquidity provision fees by up to 100%.', badge: 'Up to 0% fees', color: 'gold' },
          ].map((u, i) => (
            <motion.div
              key={u.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="stat-card"
            >
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 ${u.color === 'neon' ? 'bg-neon/10 text-neon' : 'bg-gold/10 text-gold'}`}>
                <u.icon className="w-5 h-5" />
              </div>
              <div className={`text-xs font-600 px-2 py-0.5 rounded-full w-fit mb-3 ${u.color === 'neon' ? 'bg-neon/10 text-neon' : 'bg-gold/10 text-gold'}`}>
                {u.badge}
              </div>
              <h3 className="font-display font-600 text-text text-lg mb-2">{u.title}</h3>
              <p className="text-sm text-text-muted leading-relaxed">{u.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Staking tiers */}
        <div className="mb-16">
          <div className="text-center mb-10">
            <div className="text-xs text-neon uppercase tracking-widest font-mono mb-3">Staking Tiers</div>
            <h2 className="font-display text-4xl font-700 text-text">
              Stake more. <span className="gradient-text-neon">Earn more.</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {stakingTiers.map((tier, i) => (
              <motion.div
                key={tier.tier}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-surface border border-border rounded-2xl p-6 hover:border-opacity-50 transition-all"
                style={{ borderColor: `${tier.color}20` }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="font-display font-700 text-lg" style={{ color: tier.color }}>{tier.tier}</div>
                  <Lock className="w-4 h-4 text-text-muted" />
                </div>
                <div className="font-mono text-xs text-text-muted mb-1">Minimum</div>
                <div className="font-mono font-600 text-text mb-4">{tier.min}</div>
                <div className="text-center py-4 rounded-xl mb-4" style={{ background: `${tier.color}10` }}>
                  <div className="font-display text-3xl font-700" style={{ color: tier.color }}>{tier.apy}</div>
                  <div className="text-xs text-text-muted">Annual APY</div>
                </div>
                <ul className="space-y-2">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-text-muted">
                      <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: tier.color }} />
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Tokenomics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center mb-16">
          <div>
            <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">Tokenomics</div>
            <h2 className="font-display text-4xl font-700 text-text mb-6">
              Fair distribution.<br />
              <span className="gradient-text-gold">Long-term aligned.</span>
            </h2>
            <div className="space-y-3">
              {tokenomics.map((t) => (
                <div key={t.label}>
                  <div className="flex items-center justify-between mb-1.5 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-sm" style={{ background: t.color }} />
                      <span className="text-text-muted">{t.label}</span>
                    </div>
                    <span className="font-mono font-600 text-text">{t.pct}%</span>
                  </div>
                  <div className="w-full h-2 bg-surface-2 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${t.pct}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className="h-full rounded-full"
                      style={{ background: t.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-sm text-text-muted">
              Total Supply: <span className="text-gold font-mono font-600">10,000,000 LQX</span>
            </div>
          </div>

          {/* Pie chart visual */}
          <div className="flex items-center justify-center">
            <div className="relative w-64 h-64">
              <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
                {tokenomics.reduce((acc, t, i) => {
                  const prev = acc.offset;
                  const pct = t.pct / 100;
                  const circumference = 2 * Math.PI * 80;
                  const dash = pct * circumference;
                  const gap = circumference - dash;
                  const offset = circumference - prev * circumference;
                  acc.offset += pct;
                  acc.elements.push(
                    <circle
                      key={t.label}
                      cx="100" cy="100" r="80"
                      fill="none"
                      stroke={t.color}
                      strokeWidth="20"
                      strokeDasharray={`${dash} ${gap}`}
                      strokeDashoffset={offset}
                    />
                  );
                  return acc;
                }, { offset: 0, elements: [] as any[] }).elements}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <div className="font-mono text-xs text-text-muted">Total</div>
                <div className="font-display text-2xl font-700 text-gold">10M</div>
                <div className="font-mono text-xs text-text-muted">LQX</div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl border border-gold/20 bg-gold/5 p-10 text-center"
        >
          <h2 className="font-display text-3xl font-700 text-text mb-3">
            Start earning with <span className="gradient-text-gold">LQX</span>
          </h2>
          <p className="text-text-muted mb-6">Stake LQX, earn protocol revenue, govern the future of DeFi liquidity.</p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="btn-gold flex items-center gap-2">
              Buy LQX <ArrowRight className="w-4 h-4" />
            </button>
            <button className="btn-outline flex items-center gap-2">
              Stake Now <Lock className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
