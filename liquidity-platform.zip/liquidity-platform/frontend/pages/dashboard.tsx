import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet, TrendingUp, TrendingDown, Plus, Minus, RotateCcw, Gift,
  BarChart2, Activity, Clock, ChevronRight, ArrowUpRight, ArrowDownRight,
  DollarSign, Percent, Zap, Layers, Lock
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import StatCard from '../components/common/StatCard';

const mockPositions = [
  { pair: 'BTC/USDC', deposited: '$45,200', value: '$52,840', apy: '18.4%', earned: '$892', status: 'active', days: 34 },
  { pair: 'ETH/USDC', deposited: '$28,000', value: '$31,920', apy: '22.1%', earned: '$543', status: 'active', days: 21 },
  { pair: 'ARB/USDC', deposited: '$10,000', value: '$9,670', apy: '34.7%', earned: '$187', status: 'active', days: 8 },
];

const mockTransactions = [
  { type: 'deposit', pool: 'BTC/USDC', amount: '+$15,000', time: '2h ago', status: 'success' },
  { type: 'rewards', pool: 'ETH/USDC', amount: '+$87.40', time: '6h ago', status: 'success' },
  { type: 'withdraw', pool: 'ARB/USDC', amount: '-$5,000', time: '1d ago', status: 'success' },
  { type: 'stake', pool: 'LQX Staking', amount: '10,000 LQX', time: '2d ago', status: 'success' },
  { type: 'compound', pool: 'ETH/USDC', amount: '+$45.20', time: '3d ago', status: 'success' },
];

const stakingData = {
  staked: '10,000 LQX',
  stakingValue: '$12,400',
  pendingRewards: '$324.50',
  apy: '67.2%',
  lockPeriod: '30 days',
  unlockIn: '18d 4h',
};

export default function Dashboard() {
  const [connected, setConnected] = useState(false);
  const [activeTab, setActiveTab] = useState<'positions' | 'transactions' | 'staking'>('positions');
  const [modalOpen, setModalOpen] = useState<null | 'add' | 'remove' | 'stake' | 'claim'>(null);
  const [selectedPool, setSelectedPool] = useState('');
  const [amount, setAmount] = useState('');

  const connectWallet = async () => {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      try {
        await (window as any).ethereum.request({ method: 'eth_requestAccounts' });
        setConnected(true);
      } catch {}
    } else {
      setConnected(true); // Demo mode
    }
  };

  const totalValue = '$94,430';
  const totalEarned = '$1,622.40';
  const portfolioChange = '+12.4%';

  return (
    <Layout noFooter={false}>
      <Head>
        <title>Dashboard — LiquidityX</title>
      </Head>

      <div className="min-h-screen py-8 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8"
        >
          <div>
            <h1 className="font-display text-3xl font-700 text-text">Dashboard</h1>
            <p className="text-text-muted text-sm mt-1">Manage your liquidity positions and earnings</p>
          </div>
          {connected ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-neon/10 border border-neon/30 rounded-xl">
                <div className="w-2 h-2 rounded-full bg-neon animate-pulse" />
                <span className="text-neon text-sm font-mono">0x1a2b...3c4d</span>
              </div>
              <button className="btn-outline text-sm py-2 px-4">Disconnect</button>
            </div>
          ) : (
            <button onClick={connectWallet} className="btn-neon flex items-center gap-2 text-sm">
              <Wallet className="w-4 h-4" />
              Connect Wallet
            </button>
          )}
        </motion.div>

        {!connected ? (
          <ConnectWalletPrompt onConnect={connectWallet} />
        ) : (
          <>
            {/* Stats row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard
                label="Portfolio Value"
                value={totalValue}
                change="+$10,230"
                changeUp={true}
                icon={<DollarSign className="w-5 h-5" />}
                accent="neon"
              />
              <StatCard
                label="Total Earned"
                value={totalEarned}
                change="+$87.40"
                changeUp={true}
                icon={<TrendingUp className="w-5 h-5" />}
                accent="gold"
              />
              <StatCard
                label="Active Positions"
                value="3"
                change="Pools active"
                icon={<Layers className="w-5 h-5" />}
                accent="neon"
              />
              <StatCard
                label="Avg APY"
                value="24.8%"
                change="+2.1% vs last week"
                changeUp={true}
                icon={<Percent className="w-5 h-5" />}
                accent="gold"
              />
            </div>

            {/* Quick actions */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
              {[
                { label: 'Add Liquidity', icon: Plus, color: 'neon', action: () => setModalOpen('add') },
                { label: 'Remove', icon: Minus, color: 'text', action: () => setModalOpen('remove') },
                { label: 'Stake LP', icon: Lock, color: 'gold', action: () => setModalOpen('stake') },
                { label: 'Claim Rewards', icon: Gift, color: 'neon', action: () => setModalOpen('claim') },
              ].map(({ label, icon: Icon, color, action }) => (
                <button
                  key={label}
                  onClick={action}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-surface border border-border rounded-xl text-sm font-500 hover:border-neon/30 hover:bg-surface-2 transition-all"
                >
                  <Icon className={`w-4 h-4 ${
                    color === 'neon' ? 'text-neon' : color === 'gold' ? 'text-gold' : 'text-text-muted'
                  }`} />
                  <span className="text-text">{label}</span>
                </button>
              ))}
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-1 mb-6 bg-surface p-1 rounded-xl w-fit border border-border">
              {(['positions', 'transactions', 'staking'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-2 rounded-lg text-sm font-500 capitalize transition-all ${
                    activeTab === tab
                      ? 'bg-neon text-background font-700'
                      : 'text-text-muted hover:text-text'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <AnimatePresence mode="wait">
              {activeTab === 'positions' && (
                <motion.div
                  key="positions"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="bg-surface border border-border rounded-2xl overflow-hidden">
                    <div className="p-5 border-b border-border flex items-center justify-between">
                      <h3 className="font-600 text-text">Active Positions</h3>
                      <Link href="/pools" className="text-neon text-sm flex items-center gap-1 hover:gap-2 transition-all">
                        Add Position <ChevronRight className="w-4 h-4" />
                      </Link>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Pool</th>
                            <th>Deposited</th>
                            <th>Current Value</th>
                            <th>APY</th>
                            <th>Earned</th>
                            <th>Duration</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {mockPositions.map((pos) => {
                            const pnlPositive = parseFloat(pos.value.replace(/[^0-9.]/g, '')) > parseFloat(pos.deposited.replace(/[^0-9.]/g, ''));
                            return (
                              <tr key={pos.pair}>
                                <td>
                                  <div className="flex items-center gap-2">
                                    <div className="status-dot-active" />
                                    <span className="font-mono font-600 text-text">{pos.pair}</span>
                                  </div>
                                </td>
                                <td className="font-mono text-text-muted">{pos.deposited}</td>
                                <td>
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-mono font-600 text-text">{pos.value}</span>
                                    {pnlPositive
                                      ? <ArrowUpRight className="w-3 h-3 text-neon" />
                                      : <ArrowDownRight className="w-3 h-3 text-danger" />
                                    }
                                  </div>
                                </td>
                                <td><span className="font-mono font-700 text-neon">{pos.apy}</span></td>
                                <td><span className="font-mono font-600 text-gold">{pos.earned}</span></td>
                                <td><span className="text-text-muted text-sm">{pos.days}d</span></td>
                                <td>
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={() => { setSelectedPool(pos.pair); setModalOpen('add'); }}
                                      className="text-neon text-xs hover:underline"
                                    >+Add</button>
                                    <span className="text-border">|</span>
                                    <button
                                      onClick={() => { setSelectedPool(pos.pair); setModalOpen('remove'); }}
                                      className="text-text-muted text-xs hover:text-danger hover:underline transition-colors"
                                    >Remove</button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'transactions' && (
                <motion.div
                  key="transactions"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="bg-surface border border-border rounded-2xl overflow-hidden">
                    <div className="p-5 border-b border-border">
                      <h3 className="font-600 text-text">Transaction History</h3>
                    </div>
                    <div className="divide-y divide-border">
                      {mockTransactions.map((tx, i) => (
                        <div key={i} className="flex items-center justify-between p-4 hover:bg-surface-2 transition-colors">
                          <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                              tx.type === 'deposit' ? 'bg-neon/10 text-neon' :
                              tx.type === 'withdraw' ? 'bg-danger/10 text-danger' :
                              tx.type === 'rewards' ? 'bg-gold/10 text-gold' :
                              'bg-surface-3 text-text-muted'
                            }`}>
                              {tx.type === 'deposit' ? <ArrowDownRight className="w-4 h-4" /> :
                               tx.type === 'withdraw' ? <ArrowUpRight className="w-4 h-4" /> :
                               tx.type === 'rewards' ? <Gift className="w-4 h-4" /> :
                               tx.type === 'stake' ? <Lock className="w-4 h-4" /> :
                               <RotateCcw className="w-4 h-4" />}
                            </div>
                            <div>
                              <div className="font-500 text-text text-sm capitalize">{tx.type}</div>
                              <div className="text-text-muted text-xs">{tx.pool}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`font-mono font-600 text-sm ${
                              tx.amount.startsWith('+') ? 'text-neon' :
                              tx.amount.startsWith('-') ? 'text-danger' : 'text-text'
                            }`}>{tx.amount}</div>
                            <div className="text-text-muted text-xs">{tx.time}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'staking' && (
                <motion.div
                  key="staking"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                    {/* Staking stats */}
                    <div className="lg:col-span-2 bg-surface border border-border rounded-2xl p-6">
                      <h3 className="font-display font-700 text-text text-xl mb-6 flex items-center gap-2">
                        <Zap className="w-5 h-5 text-gold" />
                        LQX Staking
                        <span className="text-xs font-mono text-gold bg-gold/10 px-2 py-0.5 rounded-full">
                          {stakingData.apy} APY
                        </span>
                      </h3>
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        {[
                          { label: 'Staked Amount', value: stakingData.staked, color: 'gold' },
                          { label: 'Staking Value', value: stakingData.stakingValue, color: 'neon' },
                          { label: 'Pending Rewards', value: stakingData.pendingRewards, color: 'neon' },
                          { label: 'Unlocks In', value: stakingData.unlockIn, color: 'text-muted' },
                        ].map((item) => (
                          <div key={item.label} className="bg-surface-2 rounded-xl p-4">
                            <div className="text-xs text-text-muted mb-1">{item.label}</div>
                            <div className={`font-mono font-700 text-lg ${
                              item.color === 'gold' ? 'text-gold' :
                              item.color === 'neon' ? 'text-neon' : 'text-text-muted'
                            }`}>{item.value}</div>
                          </div>
                        ))}
                      </div>
                      <div className="flex gap-3">
                        <button onClick={() => setModalOpen('stake')} className="btn-gold text-sm flex-1 flex items-center justify-center gap-2 py-2.5">
                          <Plus className="w-4 h-4" /> Stake More
                        </button>
                        <button onClick={() => setModalOpen('claim')} className="btn-neon text-sm flex-1 flex items-center justify-center gap-2 py-2.5">
                          <Gift className="w-4 h-4" /> Claim ${stakingData.pendingRewards.replace('$','')}
                        </button>
                      </div>
                    </div>

                    {/* Revenue share */}
                    <div className="bg-surface border border-border rounded-2xl p-6">
                      <h3 className="font-600 text-text mb-4">Weekly Revenue Share</h3>
                      <div className="space-y-3">
                        {[
                          { week: 'Week 147', amount: '$89.20', date: 'Jul 22' },
                          { week: 'Week 146', amount: '$76.40', date: 'Jul 15' },
                          { week: 'Week 145', amount: '$94.10', date: 'Jul 8' },
                          { week: 'Week 144', amount: '$64.90', date: 'Jul 1' },
                        ].map((item) => (
                          <div key={item.week} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                            <div>
                              <div className="text-sm text-text">{item.week}</div>
                              <div className="text-xs text-text-muted">{item.date}</div>
                            </div>
                            <div className="font-mono font-600 text-gold">{item.amount}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {modalOpen && (
          <ActionModal
            type={modalOpen}
            pool={selectedPool}
            amount={amount}
            setAmount={setAmount}
            onClose={() => { setModalOpen(null); setAmount(''); }}
          />
        )}
      </AnimatePresence>
    </Layout>
  );
}

function ConnectWalletPrompt({ onConnect }: { onConnect: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-32 text-center"
    >
      <div className="w-20 h-20 rounded-2xl bg-neon/10 border border-neon/20 flex items-center justify-center mb-6">
        <Wallet className="w-10 h-10 text-neon" />
      </div>
      <h2 className="font-display text-2xl font-700 text-text mb-3">Connect Your Wallet</h2>
      <p className="text-text-muted mb-8 max-w-sm">
        Connect your wallet to view your portfolio, manage positions, and claim rewards.
      </p>
      <div className="flex flex-col gap-3 w-full max-w-xs">
        <button onClick={onConnect} className="btn-neon flex items-center justify-center gap-3 py-3.5">
          <img src="https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg" alt="MetaMask" className="w-5 h-5" />
          MetaMask
        </button>
        <button onClick={onConnect} className="btn-outline flex items-center justify-center gap-3 py-3.5">
          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-400 to-purple-500" />
          WalletConnect
        </button>
        <button onClick={onConnect} className="btn-outline flex items-center justify-center gap-3 py-3.5 text-text-muted hover:text-text">
          <div className="w-5 h-5 rounded bg-gradient-to-br from-blue-500 to-blue-700" />
          Coinbase Wallet
        </button>
      </div>
    </motion.div>
  );
}

function ActionModal({
  type, pool, amount, setAmount, onClose
}: {
  type: string;
  pool: string;
  amount: string;
  setAmount: (v: string) => void;
  onClose: () => void;
}) {
  const titles: Record<string, string> = {
    add: 'Add Liquidity',
    remove: 'Remove Liquidity',
    stake: 'Stake LP Tokens',
    claim: 'Claim Rewards',
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-surface border border-border rounded-2xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-display font-700 text-xl text-text">{titles[type]}</h3>
          <button onClick={onClose} className="text-text-muted hover:text-text transition-colors text-xl">✕</button>
        </div>

        {type === 'claim' ? (
          <div className="text-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-neon/10 flex items-center justify-center mx-auto mb-4">
              <Gift className="w-8 h-8 text-neon" />
            </div>
            <div className="font-display text-3xl font-700 text-neon mb-1">$1,622.40</div>
            <div className="text-text-muted text-sm mb-6">Available to claim</div>
            <button className="btn-neon w-full py-3">Claim All Rewards</button>
          </div>
        ) : (
          <div className="space-y-4">
            {pool && (
              <div className="flex items-center gap-2 p-3 bg-surface-2 rounded-xl">
                <div className="status-dot-active" />
                <span className="font-mono font-600 text-neon">{pool}</span>
              </div>
            )}
            <div>
              <label className="text-xs text-text-muted uppercase tracking-wider mb-2 block">Amount (USDC)</label>
              <div className="relative">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="input-field pr-16 text-xl font-mono"
                />
                <button
                  onClick={() => setAmount('10000')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neon text-xs font-600 hover:underline"
                >
                  MAX
                </button>
              </div>
            </div>
            <div className="bg-surface-2 rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-text-muted">Estimated APY</span>
                <span className="text-neon font-600">18.4%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-text-muted">Pool Share</span>
                <span className="text-text font-mono">0.023%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-text-muted">Gas Fee</span>
                <span className="text-text font-mono">~$4.20</span>
              </div>
            </div>
            <button className={`w-full py-3 ${type === 'remove' ? 'btn-outline' : 'btn-neon'}`}>
              {titles[type]}
            </button>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
