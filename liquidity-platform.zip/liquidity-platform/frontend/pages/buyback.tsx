import { useState } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import { Flame, Zap, TrendingDown, Clock, BarChart3, ArrowRight } from 'lucide-react';
import Layout from '../components/layout/Layout';

const history = [
  { week: 147, date: 'Jul 22, 2025', feesCollected: '$312,400', lqxBought: '28,400 LQX', avgPrice: '$1.24', burned: '28,400 LQX', status: 'Completed' },
  { week: 146, date: 'Jul 15, 2025', feesCollected: '$287,900', lqxBought: '24,100 LQX', avgPrice: '$1.19', burned: '24,100 LQX', status: 'Completed' },
  { week: 145, date: 'Jul 8, 2025', feesCollected: '$354,200', lqxBought: '31,200 LQX', avgPrice: '$1.32', burned: '31,200 LQX', status: 'Completed' },
  { week: 144, date: 'Jul 1, 2025', feesCollected: '$241,800', lqxBought: '22,800 LQX', avgPrice: '$1.18', burned: '22,800 LQX', status: 'Completed' },
  { week: 143, date: 'Jun 24, 2025', feesCollected: '$298,600', lqxBought: '27,300 LQX', avgPrice: '$1.21', burned: '27,300 LQX', status: 'Completed' },
  { week: 142, date: 'Jun 17, 2025', feesCollected: '$334,100', lqxBought: '29,900 LQX', avgPrice: '$1.28', burned: '29,900 LQX', status: 'Completed' },
];

const metrics = [
  { label: 'Total Fees Collected', value: '$12.4M', icon: BarChart3, color: 'neon' },
  { label: 'Total LQX Burned', value: '2.1M LQX', icon: Flame, color: 'gold' },
  { label: 'Current Burn Rate', value: '$87K/week', icon: TrendingDown, color: 'neon' },
  { label: 'Next Buyback', value: '14h 23m', icon: Clock, color: 'gold' },
];

export default function Buyback() {
  const [activeTab, setActiveTab] = useState<'overview' | 'history'>('overview');
  const totalBurned = 2_100_000;
  const totalSupply = 10_000_000;
  const burnedPct = (totalBurned / totalSupply) * 100;

  return (
    <Layout>
      <Head>
        <title>Buyback System — LiquidityX</title>
      </Head>

      <div className="py-12 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <div className="text-xs text-neon uppercase tracking-widest font-mono mb-3">Buyback & Burn</div>
          <h1 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
            Automated buyback.<br />
            <span className="gradient-text-neon">Permanent deflation.</span>
          </h1>
          <p className="text-text-muted max-w-xl leading-relaxed">
            40% of all trading fees are automatically used to purchase LQX from the open market every week.
            Tokens are permanently burned, reducing supply forever.
          </p>
        </motion.div>

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {metrics.map((m, i) => (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="stat-card"
            >
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${
                m.color === 'neon' ? 'bg-neon/10 text-neon' : 'bg-gold/10 text-gold'
              }`}>
                <m.icon className="w-5 h-5" />
              </div>
              <div className={`font-display text-2xl font-700 mb-1 ${m.color === 'neon' ? 'text-neon' : 'text-gold'}`}>
                {m.value}
              </div>
              <div className="text-xs text-text-muted">{m.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Burn progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-surface border border-border rounded-2xl p-8 mb-10"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Flame className="w-6 h-6 text-gold" />
                <h2 className="font-display text-2xl font-700 text-text">Supply Burn Tracker</h2>
              </div>
              <p className="text-text-muted text-sm">Tracking the permanent reduction of LQX supply over time</p>
            </div>
            <div className="text-right">
              <div className="font-display text-3xl font-700 text-gold">{burnedPct.toFixed(1)}%</div>
              <div className="text-text-muted text-xs">of total supply burned</div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="relative mb-6">
            <div className="w-full h-3 bg-surface-2 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${burnedPct}%` }}
                transition={{ duration: 1.5, ease: 'easeOut', delay: 0.5 }}
                className="h-full rounded-full relative"
                style={{ background: 'linear-gradient(90deg, #D4AF37, #F0D060)' }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/10" />
              </motion.div>
            </div>
            <div className="flex justify-between mt-2 text-xs text-text-muted font-mono">
              <span>0</span>
              <span>{totalBurned.toLocaleString()} burned</span>
              <span>{totalSupply.toLocaleString()} total</span>
            </div>
          </div>

          {/* Supply breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-surface-2 rounded-xl p-5 border border-border">
              <div className="text-xs text-text-muted mb-1">Total Supply</div>
              <div className="font-mono font-700 text-2xl text-text">10,000,000</div>
              <div className="text-xs text-text-muted mt-1">LQX</div>
            </div>
            <div className="bg-gold/5 rounded-xl p-5 border border-gold/20">
              <div className="text-xs text-text-muted mb-1">Burned Forever</div>
              <div className="font-mono font-700 text-2xl text-gold">2,100,000</div>
              <div className="text-xs text-gold mt-1">↓ 21% of supply</div>
            </div>
            <div className="bg-neon/5 rounded-xl p-5 border border-neon/20">
              <div className="text-xs text-text-muted mb-1">Circulating Supply</div>
              <div className="font-mono font-700 text-2xl text-neon">7,900,000</div>
              <div className="text-xs text-neon mt-1">↓ Continuously reducing</div>
            </div>
          </div>
        </motion.div>

        {/* How it works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-10"
        >
          <h2 className="font-display text-2xl font-700 text-text mb-6">How the Buyback Engine Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { step: '01', title: 'Fees Collected', desc: 'Trading fees accumulate from all pools and market making operations', color: 'neon' },
              { step: '02', title: 'Fee Split', desc: '40% allocated for buyback, 60% distributed to stakers weekly', color: 'gold' },
              { step: '03', title: 'Market Buy', desc: 'Smart contract executes TWAP buy of LQX to minimize price impact', color: 'neon' },
              { step: '04', title: 'Permanent Burn', desc: 'Purchased tokens sent to 0x000...dead address. Irreversible.', color: 'gold' },
            ].map((s) => (
              <div key={s.step} className="stat-card">
                <div className={`font-mono text-4xl font-700 mb-3 ${s.color === 'neon' ? 'text-neon/20' : 'text-gold/20'}`}>
                  {s.step}
                </div>
                <h3 className={`font-600 text-text mb-2 ${s.color === 'neon' ? '' : ''}`}>{s.title}</h3>
                <p className="text-sm text-text-muted leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* History table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h2 className="font-display text-2xl font-700 text-text mb-5">Buyback History</h2>
          <div className="bg-surface border border-border rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Week</th>
                    <th>Date</th>
                    <th>Fees Collected</th>
                    <th>LQX Bought</th>
                    <th>Avg Buy Price</th>
                    <th>Tokens Burned</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((row, i) => (
                    <motion.tr
                      key={row.week}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <td><span className="font-mono font-600 text-text">#{row.week}</span></td>
                      <td className="text-text-muted text-sm">{row.date}</td>
                      <td className="font-mono text-neon">{row.feesCollected}</td>
                      <td className="font-mono text-text">{row.lqxBought}</td>
                      <td className="font-mono text-text-muted">{row.avgPrice}</td>
                      <td>
                        <span className="flex items-center gap-1.5 font-mono text-gold">
                          <Flame className="w-3 h-3" />
                          {row.burned}
                        </span>
                      </td>
                      <td>
                        <span className="badge-up">{row.status}</span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
