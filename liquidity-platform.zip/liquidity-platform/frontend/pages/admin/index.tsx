import { useState, useEffect } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import {
  Shield, Settings, TrendingUp, Zap, BarChart3, Users, Plus, Edit2,
  Trash2, Play, AlertTriangle, Lock, Activity
} from 'lucide-react';
import Layout from '../../components/layout/Layout';

const mockPools = [
  { id: 1, pair: 'BTC/USDC', tvl: '$423M', apy: 18.4, active: true },
  { id: 2, pair: 'ETH/USDC', tvl: '$312M', apy: 22.1, active: true },
  { id: 3, pair: 'ARB/USDC', tvl: '$87M', apy: 34.7, active: true },
  { id: 4, pair: 'OP/USDC', tvl: '$56M', apy: 41.2, active: false },
];

const ADMIN_PASS = 'admin123'; // Demo only — use env-based auth in production

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'pools' | 'buyback' | 'analytics' | 'settings'>('pools');
  const [editPool, setEditPool] = useState<any>(null);
  const [pools, setPools] = useState(mockPools);
  const [buybackTriggered, setBuybackTriggered] = useState(false);

  const login = (e: React.FormEvent) => {
    e.preventDefault();
    if (pass === ADMIN_PASS) {
      setAuthed(true);
    } else {
      setError('Invalid credentials');
    }
  };

  if (!authed) {
    return (
      <Layout noFooter>
        <Head><title>Admin — LiquidityX</title></Head>
        <div className="min-h-screen flex items-center justify-center px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-surface border border-border rounded-2xl p-8"
          >
            <div className="w-12 h-12 rounded-xl bg-neon/10 flex items-center justify-center mx-auto mb-5">
              <Shield className="w-6 h-6 text-neon" />
            </div>
            <h1 className="font-display text-2xl font-700 text-text text-center mb-2">Admin Access</h1>
            <p className="text-text-muted text-sm text-center mb-6">Restricted area. Authorized personnel only.</p>
            <form onSubmit={login} className="space-y-4">
              <input
                type="password"
                placeholder="Enter admin password"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                className="input-field"
              />
              {error && <div className="text-danger text-sm">{error}</div>}
              <button type="submit" className="btn-neon w-full py-3 flex items-center justify-center gap-2">
                <Lock className="w-4 h-4" /> Authenticate
              </button>
            </form>
            <div className="mt-4 text-center text-xs text-text-muted">Demo password: admin123</div>
          </motion.div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout noFooter>
      <Head><title>Admin Panel — LiquidityX</title></Head>
      <div className="py-8 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-5 h-5 text-neon" />
              <h1 className="font-display text-2xl font-700 text-text">Admin Panel</h1>
              <span className="text-xs bg-neon/10 text-neon px-2 py-0.5 rounded-full font-mono">RESTRICTED</span>
            </div>
            <p className="text-text-muted text-sm">Protocol management and analytics</p>
          </div>
          <button onClick={() => setAuthed(false)} className="text-text-muted hover:text-danger text-sm transition-colors">
            Logout
          </button>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Protocol TVL', value: '$2.4B', icon: BarChart3, color: 'neon' },
            { label: '24h Fees', value: '$87,400', icon: TrendingUp, color: 'gold' },
            { label: 'Active Users', value: '2,847', icon: Users, color: 'neon' },
            { label: 'Active Pools', value: '47', icon: Activity, color: 'gold' },
          ].map((s) => (
            <div key={s.label} className="stat-card">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-3 ${s.color === 'neon' ? 'bg-neon/10 text-neon' : 'bg-gold/10 text-gold'}`}>
                <s.icon className="w-4 h-4" />
              </div>
              <div className={`font-display text-2xl font-700 mb-0.5 ${s.color === 'neon' ? 'text-neon' : 'text-gold'}`}>{s.value}</div>
              <div className="text-xs text-text-muted">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-surface p-1 rounded-xl w-fit border border-border mb-6">
          {(['pools', 'buyback', 'analytics', 'settings'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 rounded-lg text-sm font-500 capitalize transition-all ${
                activeTab === tab ? 'bg-neon text-background font-700' : 'text-text-muted hover:text-text'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Pool Management */}
        {activeTab === 'pools' && (
          <div>
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-xl font-700 text-text">Pool Management</h2>
              <button className="btn-neon text-sm py-2 px-4 flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add Pool
              </button>
            </div>
            <div className="bg-surface border border-border rounded-2xl overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Pool</th><th>TVL</th><th>APY</th><th>Status</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pools.map((pool) => (
                    <tr key={pool.id}>
                      <td className="font-mono font-600 text-text">{pool.pair}</td>
                      <td className="font-mono text-text-muted">{pool.tvl}</td>
                      <td>
                        {editPool?.id === pool.id ? (
                          <input
                            type="number"
                            value={editPool.apy}
                            onChange={(e) => setEditPool({ ...editPool, apy: parseFloat(e.target.value) })}
                            className="input-field py-1 w-24 text-sm"
                          />
                        ) : (
                          <span className="font-mono text-neon font-600">{pool.apy}%</span>
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => setPools(pools.map(p => p.id === pool.id ? { ...p, active: !p.active } : p))}
                          className={`px-3 py-1 rounded-full text-xs font-600 ${pool.active ? 'bg-neon/10 text-neon' : 'bg-danger/10 text-danger'}`}
                        >
                          {pool.active ? 'Active' : 'Paused'}
                        </button>
                      </td>
                      <td>
                        <div className="flex items-center gap-2">
                          {editPool?.id === pool.id ? (
                            <>
                              <button
                                onClick={() => {
                                  setPools(pools.map(p => p.id === pool.id ? { ...p, apy: editPool.apy } : p));
                                  setEditPool(null);
                                }}
                                className="text-neon text-xs hover:underline"
                              >Save</button>
                              <button onClick={() => setEditPool(null)} className="text-text-muted text-xs hover:underline">Cancel</button>
                            </>
                          ) : (
                            <>
                              <button onClick={() => setEditPool(pool)} className="text-text-muted hover:text-neon transition-colors">
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button className="text-text-muted hover:text-danger transition-colors">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Buyback Management */}
        {activeTab === 'buyback' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl font-700 text-text">Buyback Control</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="stat-card">
                <div className="text-xs text-text-muted mb-1">Pending Fees for Buyback</div>
                <div className="font-display text-2xl font-700 text-neon">$124,800</div>
                <div className="text-xs text-text-muted mt-1">40% of $312,000 collected</div>
              </div>
              <div className="stat-card">
                <div className="text-xs text-text-muted mb-1">Last Buyback</div>
                <div className="font-display text-2xl font-700 text-gold">3d ago</div>
                <div className="text-xs text-text-muted mt-1">28,400 LQX burned</div>
              </div>
              <div className="stat-card">
                <div className="text-xs text-text-muted mb-1">Auto-Buyback Status</div>
                <div className="font-display text-2xl font-700 text-neon">Active</div>
                <div className="text-xs text-text-muted mt-1">Every Sunday 00:00 UTC</div>
              </div>
            </div>

            <div className="bg-surface border border-border rounded-2xl p-6">
              <h3 className="font-600 text-text mb-4">Manual Buyback Trigger</h3>
              <div className="flex items-center gap-4 p-4 bg-warning/10 border border-warning/20 rounded-xl mb-5">
                <AlertTriangle className="w-5 h-5 text-warning flex-shrink-0" />
                <p className="text-sm text-warning">
                  Manual buyback will execute immediately. This action cannot be undone. Ensure you have the proper authorization.
                </p>
              </div>
              {!buybackTriggered ? (
                <button
                  onClick={() => setBuybackTriggered(true)}
                  className="btn-neon flex items-center gap-2 text-sm"
                >
                  <Play className="w-4 h-4" /> Execute Manual Buyback
                </button>
              ) : (
                <div className="flex items-center gap-3 text-neon">
                  <div className="loader" />
                  <span className="text-sm">Executing buyback on-chain...</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl font-700 text-text">Protocol Analytics</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {[
                { label: '7-Day TVL Trend', value: '+14.2%', sub: '$2.4B → $2.74B', color: 'neon' },
                { label: '7-Day Volume', value: '$6.23B', sub: '+8.7% vs previous week', color: 'gold' },
                { label: 'New Users (7d)', value: '847', sub: '+23% vs previous week', color: 'neon' },
                { label: 'Revenue (7d)', value: '$1.87M', sub: '40% to buyback, 60% to stakers', color: 'gold' },
              ].map((a) => (
                <div key={a.label} className="stat-card">
                  <div className="text-xs text-text-muted mb-2">{a.label}</div>
                  <div className={`font-display text-3xl font-700 mb-1 ${a.color === 'neon' ? 'text-neon' : 'text-gold'}`}>{a.value}</div>
                  <div className="text-sm text-text-muted">{a.sub}</div>
                </div>
              ))}
            </div>

            {/* Top pools */}
            <div className="bg-surface border border-border rounded-2xl overflow-hidden">
              <div className="p-5 border-b border-border font-600 text-text">Top Performing Pools (7d)</div>
              <table className="data-table">
                <thead>
                  <tr><th>Pool</th><th>TVL</th><th>Volume</th><th>Revenue</th><th>APY</th></tr>
                </thead>
                <tbody>
                  {[
                    ['BTC/USDC', '$423M', '$623M', '$1.87M', '18.4%'],
                    ['ETH/USDC', '$312M', '$938M', '$2.81M', '22.1%'],
                    ['ARB/USDC', '$87M', '$315M', '$1.57M', '34.7%'],
                  ].map(([pair, tvl, vol, rev, apy]) => (
                    <tr key={pair}>
                      <td className="font-mono font-600 text-text">{pair}</td>
                      <td className="font-mono text-text-muted">{tvl}</td>
                      <td className="font-mono text-text-muted">{vol}</td>
                      <td className="font-mono text-gold">{rev}</td>
                      <td className="font-mono text-neon font-700">{apy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <div className="space-y-5 max-w-2xl">
            <h2 className="font-display text-xl font-700 text-text">Protocol Settings</h2>
            {[
              { label: 'Default Trading Fee', value: '0.3', unit: '%' },
              { label: 'Buyback Allocation', value: '40', unit: '% of fees' },
              { label: 'Staker Rewards Allocation', value: '60', unit: '% of fees' },
              { label: 'Minimum Deposit', value: '100', unit: 'USDC' },
              { label: 'Withdrawal Delay', value: '24', unit: 'hours' },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between p-5 bg-surface border border-border rounded-xl">
                <div>
                  <div className="font-500 text-text">{s.label}</div>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    defaultValue={s.value}
                    className="input-field w-24 text-right py-1.5"
                  />
                  <span className="text-text-muted text-sm">{s.unit}</span>
                  <button className="btn-neon text-xs py-1.5 px-4">Save</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
