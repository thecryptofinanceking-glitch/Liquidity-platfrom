import { useEffect, useRef, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, ChevronRight, Shield, Zap, BarChart3, Repeat2, Coins,
  TrendingUp, Lock, Globe, Activity, CheckCircle, Star, Users, DollarSign
} from 'lucide-react';
import Layout from '../components/layout/Layout';

const pools = [
  { pair: 'BTC/USDC', tvl: '$423M', apy: '18.4%', volume: '$89M', spread: '0.02%', up: true, change: '+2.3%' },
  { pair: 'ETH/USDC', tvl: '$312M', apy: '22.1%', volume: '$134M', spread: '0.03%', up: true, change: '+1.8%' },
  { pair: 'ARB/USDC', tvl: '$87M', apy: '34.7%', volume: '$45M', spread: '0.05%', up: false, change: '-0.4%' },
  { pair: 'OP/USDC', tvl: '$56M', apy: '41.2%', volume: '$23M', spread: '0.06%', up: true, change: '+3.1%' },
  { pair: 'LINK/USDC', tvl: '$43M', apy: '28.9%', volume: '$18M', spread: '0.04%', up: true, change: '+0.9%' },
];

const services = [
  {
    icon: BarChart3,
    title: 'Deep Liquidity Pools',
    desc: 'Automated market making with concentrated liquidity, yielding up to 40%+ APY for providers.',
    badge: 'AMM v3',
    color: 'neon',
  },
  {
    icon: Repeat2,
    title: 'Market Making Services',
    desc: 'Professional market making for institutional clients and TGE projects. Tight spreads, 24/7 operations.',
    badge: 'Institutional',
    color: 'gold',
  },
  {
    icon: Zap,
    title: 'Hybrid DEX + Orderbook',
    desc: 'Best of both worlds: on-chain settlement with off-chain orderbook matching for optimal execution.',
    badge: 'Hybrid',
    color: 'neon',
  },
  {
    icon: Coins,
    title: 'Buyback + Burn Engine',
    desc: '40% of protocol fees automatically buy back and burn LQX tokens, creating deflationary pressure.',
    badge: 'Deflationary',
    color: 'gold',
  },
];

const features = [
  { icon: Shield, label: 'Audited Smart Contracts', desc: 'Certified by Certik and Trail of Bits' },
  { icon: Globe, label: 'Multi-chain Support', desc: 'Ethereum, Arbitrum, Optimism, Polygon' },
  { icon: Activity, label: 'Real-time Analytics', desc: 'Live TVL, volume, and yield tracking' },
  { icon: Lock, label: 'Non-custodial', desc: 'You always control your funds' },
  { icon: TrendingUp, label: 'Auto-compounding', desc: 'Maximize returns automatically' },
  { icon: Users, label: 'Referral System', desc: 'Earn up to 20% fee share on referrals' },
];

const tokenFeatures = [
  { title: 'Revenue Share', desc: '60% of protocol revenue distributed to stakers weekly', icon: DollarSign },
  { title: 'Governance', desc: 'Vote on protocol parameters, fee structures, and new pools', icon: CheckCircle },
  { title: 'Premium Access', desc: 'Higher APY pools and reduced fees for token holders', icon: Star },
  { title: 'Buyback Pressure', desc: '40% of fees used to buy and burn LQX continuously', icon: Zap },
];

const stats = [
  { value: '$2.4B', label: 'Total Value Locked', suffix: 'USD' },
  { value: '47', label: 'Active Pools', suffix: 'pools' },
  { value: '$890M', label: '24h Volume', suffix: 'USD' },
  { value: '120+', label: 'Trading Pairs', suffix: 'pairs' },
];

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const [count, setCount] = useState({ tvl: 0, pools: 0, volume: 0, pairs: 0 });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );
    document.querySelectorAll('.section-fade').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <Layout>
      <Head>
        <title>LiquidityX — Institutional Liquidity Infrastructure</title>
        <meta name="description" content="Deep liquidity. Tight spreads. Intelligent execution. The institutional-grade liquidity platform for digital assets." />
      </Head>

      {/* ══════════ HERO ══════════ */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden grid-bg">
        {/* Background glows */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-neon/5 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[100px]" />
          <div className="absolute top-1/3 right-1/4 w-[300px] h-[300px] bg-neon/3 rounded-full blur-[80px]" />
        </div>

        {/* Animated border lines */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <motion.div
            className="absolute h-px w-full bg-gradient-to-r from-transparent via-neon/30 to-transparent"
            animate={{ top: ['20%', '80%', '20%'] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </div>

        <motion.div style={{ y, opacity }} className="relative z-10 text-center max-w-5xl mx-auto px-4">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon/5 border border-neon/20 text-neon text-xs font-600 uppercase tracking-wider mb-8"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-neon animate-pulse" />
            Protocol v3.2 — Now Live on Arbitrum
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
            className="font-display font-900 text-5xl md:text-6xl lg:text-7xl leading-[1.05] mb-6"
          >
            Institutional
            <br />
            <span className="gradient-text-neon">Liquidity</span>{' '}
            <span className="text-text">Infrastructure</span>
            <br />
            <span className="text-text">for Digital Assets</span>
          </motion.h1>

          {/* Sub */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-lg md:text-xl text-text-muted max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Deep liquidity. Tight spreads. Intelligent execution.{' '}
            <span className="text-gold font-500">Built for institutions, accessible to everyone.</span>
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65 }}
            className="flex flex-wrap items-center justify-center gap-4 mb-16"
          >
            <Link href="/pools" className="btn-neon flex items-center gap-2 text-sm px-7 py-3.5">
              Start Providing Liquidity
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/market-making" className="btn-gold flex items-center gap-2 text-sm px-7 py-3.5">
              Request Market Making
              <ChevronRight className="w-4 h-4" />
            </Link>
            <Link href="/dashboard" className="btn-outline flex items-center gap-2 text-sm px-7 py-3.5">
              View Dashboard
            </Link>
          </motion.div>

          {/* Stat pills */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="flex flex-wrap justify-center gap-3"
          >
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 + i * 0.1 }}
                className="flex items-center gap-3 px-5 py-3 bg-surface border border-border rounded-xl"
              >
                <div className="text-xl font-display font-700 gradient-text-neon">{s.value}</div>
                <div>
                  <div className="text-xs text-text-muted">{s.label}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <div className="text-xs text-text-muted uppercase tracking-widest">Scroll</div>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-5 h-8 border border-border rounded-full flex items-start justify-center pt-1.5"
          >
            <div className="w-1 h-2 bg-neon rounded-full" />
          </motion.div>
        </motion.div>
      </section>

      {/* ══════════ POOLS OVERVIEW ══════════ */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="section-fade">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
              <div>
                <div className="text-xs text-neon uppercase tracking-widest font-mono mb-3">Liquidity Pools</div>
                <h2 className="font-display text-4xl md:text-5xl font-700 text-text">
                  Deep liquidity pools.<br />
                  <span className="gradient-text-gold">Institutional depth.</span>
                </h2>
              </div>
              <Link href="/pools" className="btn-outline text-sm flex items-center gap-2 w-fit">
                View All Pools <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Pool table */}
            <div className="bg-surface border border-border rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Pool</th>
                      <th>TVL</th>
                      <th>24h Volume</th>
                      <th>APY</th>
                      <th>Spread</th>
                      <th>24h Change</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {pools.map((pool, i) => (
                      <motion.tr
                        key={pool.pair}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.07 }}
                      >
                        <td>
                          <div className="flex items-center gap-3">
                            <div className="status-dot-active" />
                            <span className="font-mono font-600 text-text">{pool.pair}</span>
                          </div>
                        </td>
                        <td className="font-mono text-text">{pool.tvl}</td>
                        <td className="font-mono text-text-muted">{pool.volume}</td>
                        <td>
                          <span className="font-mono font-700 text-neon">{pool.apy}</span>
                        </td>
                        <td>
                          <span className="badge-neutral">{pool.spread}</span>
                        </td>
                        <td>
                          <span className={pool.up ? 'badge-up' : 'badge-down'}>
                            {pool.change}
                          </span>
                        </td>
                        <td>
                          <Link href={`/pools?pair=${pool.pair}`} className="text-neon text-sm hover:underline flex items-center gap-1">
                            Add Liquidity <ChevronRight className="w-3 h-3" />
                          </Link>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════ SERVICES ══════════ */}
      <section className="py-24 px-4 bg-surface/30">
        <div className="max-w-7xl mx-auto">
          <div className="section-fade text-center mb-16">
            <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">Our Services</div>
            <h2 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
              Everything you need<br />
              <span className="gradient-text-neon">for institutional liquidity</span>
            </h2>
            <p className="text-text-muted max-w-xl mx-auto">
              From passive liquidity provision to active market making, we cover the entire liquidity stack.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-8 group hover:border-neon/20 transition-all duration-300"
              >
                <div className="flex items-start gap-5">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    s.color === 'neon' ? 'bg-neon/10 text-neon' : 'bg-gold/10 text-gold'
                  }`}>
                    <s.icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-display text-xl font-600 text-text">{s.title}</h3>
                      <span className={`text-xs font-600 px-2 py-0.5 rounded-full ${
                        s.color === 'neon'
                          ? 'bg-neon/10 text-neon'
                          : 'bg-gold/10 text-gold'
                      }`}>
                        {s.badge}
                      </span>
                    </div>
                    <p className="text-text-muted text-sm leading-relaxed">{s.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════ BUYBACK ══════════ */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="section-fade">
              <div className="text-xs text-neon uppercase tracking-widest font-mono mb-3">Buyback Engine</div>
              <h2 className="font-display text-4xl md:text-5xl font-700 text-text mb-6">
                Continuous<br />
                <span className="gradient-text-gold">deflationary pressure</span>
              </h2>
              <p className="text-text-muted mb-8 leading-relaxed">
                40% of all protocol trading fees are automatically used to buy LQX tokens from the open market 
                and permanently burn them. Reducing supply, increasing scarcity, growing value.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { label: 'Fees Collected', value: '$12.4M', accent: 'neon' },
                  { label: 'LQX Burned', value: '2.1M', accent: 'gold' },
                  { label: 'Current Cycle', value: 'Week 147', accent: 'neon' },
                  { label: 'Next Buyback', value: '14h 23m', accent: 'gold' },
                ].map((item) => (
                  <div key={item.label} className="stat-card py-4 px-5">
                    <div className="text-xs text-text-muted mb-1">{item.label}</div>
                    <div className={`font-mono font-700 text-lg ${item.accent === 'neon' ? 'text-neon' : 'text-gold'}`}>
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>
              <Link href="/buyback" className="btn-neon inline-flex items-center gap-2 text-sm">
                View Buyback History <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Buyback visual */}
            <div className="section-fade">
              <div className="relative">
                <div className="aspect-square max-w-sm mx-auto relative">
                  {/* Outer ring */}
                  <div className="absolute inset-0 rounded-full border border-neon/10 animate-spin" style={{ animationDuration: '20s' }}>
                    {[0, 60, 120, 180, 240, 300].map((deg) => (
                      <div
                        key={deg}
                        className="absolute w-2 h-2 rounded-full bg-neon/40"
                        style={{
                          top: `${50 - 48 * Math.cos((deg * Math.PI) / 180)}%`,
                          left: `${50 + 48 * Math.sin((deg * Math.PI) / 180)}%`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      />
                    ))}
                  </div>
                  {/* Inner ring */}
                  <div className="absolute inset-6 rounded-full border border-gold/10 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }}>
                    {[0, 90, 180, 270].map((deg) => (
                      <div
                        key={deg}
                        className="absolute w-1.5 h-1.5 rounded-full bg-gold/50"
                        style={{
                          top: `${50 - 48 * Math.cos((deg * Math.PI) / 180)}%`,
                          left: `${50 + 48 * Math.sin((deg * Math.PI) / 180)}%`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      />
                    ))}
                  </div>
                  {/* Center */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-32 h-32 rounded-full bg-neon/5 border border-neon/20 flex flex-col items-center justify-center text-center shadow-neon">
                      <Zap className="w-8 h-8 text-neon mb-1" />
                      <div className="text-xs text-neon font-mono font-600">BURN</div>
                      <div className="text-xl font-700 text-text font-mono">40%</div>
                      <div className="text-xs text-text-muted">of fees</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════ TOKEN UTILITY ══════════ */}
      <section className="py-24 px-4 bg-surface/30">
        <div className="max-w-7xl mx-auto">
          <div className="section-fade text-center mb-16">
            <div className="text-xs text-gold uppercase tracking-widest font-mono mb-3">LQX Token</div>
            <h2 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
              <span className="gradient-text-gold">Real utility.</span>{' '}
              Real value.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {tokenFeatures.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="stat-card text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-gold/10 text-gold flex items-center justify-center mx-auto mb-4">
                  <f.icon className="w-6 h-6" />
                </div>
                <h3 className="font-display font-600 text-text mb-2">{f.title}</h3>
                <p className="text-sm text-text-muted leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link href="/token" className="btn-gold inline-flex items-center gap-2">
              Explore Token Utility <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ══════════ FEATURES GRID ══════════ */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="section-fade text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
              Built for <span className="gradient-text-neon">institutions</span>
            </h2>
            <p className="text-text-muted max-w-xl mx-auto">
              Enterprise-grade infrastructure with the decentralized ethos you expect from DeFi.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <motion.div
                key={f.label}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="glass-card p-6 flex items-start gap-4"
              >
                <div className="w-10 h-10 rounded-lg bg-neon/10 text-neon flex items-center justify-center flex-shrink-0">
                  <f.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-600 text-text mb-1">{f.label}</div>
                  <div className="text-sm text-text-muted">{f.desc}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════ CTA BANNER ══════════ */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden border border-neon/20 p-12 text-center"
            style={{ background: 'linear-gradient(135deg, rgba(0,255,178,0.05) 0%, rgba(212,175,55,0.05) 100%)' }}
          >
            <div className="absolute inset-0 bg-glow-neon opacity-30" />
            <div className="relative z-10">
              <div className="text-xs text-neon uppercase tracking-widest font-mono mb-4">Start Today</div>
              <h2 className="font-display text-4xl md:text-5xl font-700 text-text mb-4">
                Ready to unlock<br />
                <span className="gradient-text-neon">institutional liquidity?</span>
              </h2>
              <p className="text-text-muted mb-8 max-w-lg mx-auto">
                Join 2,400+ liquidity providers generating yield on the most capital-efficient DeFi protocol.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/pools" className="btn-neon text-sm flex items-center gap-2 px-8 py-3.5">
                  Start Providing Liquidity <ArrowRight className="w-4 h-4" />
                </Link>
                <Link href="/market-making" className="btn-outline text-sm flex items-center gap-2 px-8 py-3.5">
                  Talk to Our Team
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
