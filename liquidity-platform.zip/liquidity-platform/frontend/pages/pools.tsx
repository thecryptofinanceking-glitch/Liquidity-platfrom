import { useState } from 'react';
import Head from 'next/head';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Filter, ArrowUpDown, Plus, Info, TrendingUp,
  BarChart2, Droplets, Percent, ChevronDown, X, RotateCcw
} from 'lucide-react';
import Layout from '../components/layout/Layout';

const allPools = [
  { id: 1, pair: 'BTC/USDC', token0: 'BTC', token1: 'USDC', tvl: 423_000_000, volume: 89_000_000, apy: 18.4, spread: 0.02, fee: 0.3, category: 'Blue Chip', autoCompound: true },
  { id: 2, pair: 'ETH/USDC', token0: 'ETH', token1: 'USDC', tvl: 312_000_000, volume: 134_000_000, apy: 22.1, spread: 0.03, fee: 0.3, category: 'Blue Chip', autoCompound: true },
  { id: 3, pair: 'ARB/USDC', token0: 'ARB', token1: 'USDC', tvl: 87_000_000, volume: 45_000_000, apy: 34.7, spread: 0.05, fee: 0.5, category: 'L2', autoCompound: true },
  { id: 4, pair: 'OP/USDC', token0: 'OP', token1: 'USDC', tvl: 56_000_000, volume: 23_000_000, apy: 41.2, spread: 0.06, fee: 0.5, category: 'L2', autoCompound: false },
  { id: 5, pair: 'LINK/USDC', token0: 'LINK', token1: 'USDC', tvl: 43_000_000, volume: 18_000_000, apy: 28.9, spread: 0.04, fee: 0.3, category: 'Oracle', autoCompound: true },
  { id: 6, pair: 'UNI/USDC', token0: 'UNI', token1: 'USDC', tvl: 38_000_000, volume: 21_000_000, apy: 31.4, spread: 0.04, fee: 0.3, category: 'DeFi', autoCompound: true },
  { id: 7, pair: 'AAVE/USDC', token0: 'AAVE', token1: 'USDC', tvl: 29_000_000, volume: 12_000_000, apy: 26.7, spread: 0.05, fee: 0.5, category: 'DeFi', autoCompound: false },
  { id: 8, pair: 'GMX/USDC', token0: 'GMX', token1: 'USDC', tvl: 19_000_000, volume: 8_000_000, apy: 48.3, spread: 0.08, fee: 1.0, category: 'DeFi', autoCompound: true },
  { id: 9, pair: 'LDO/USDC', token0: 'LDO', token1: 'USDC', tvl: 15_000_000, volume: 7_000_000, apy: 52.1, spread: 0.09, fee: 1.0, category: 'LST', autoCompound: true },
  { id: 10, pair: 'CRV/USDC', token0: 'CRV', token1: 'USDC', tvl: 12_000_000, volume: 5_000_000, apy: 67.8, spread: 0.12, fee: 1.0, category: 'DeFi', autoCompound: false },
];

const categories = ['All', 'Blue Chip', 'L2', 'DeFi', 'Oracle', 'LST'];

const fmt = (n: number) => {
  if (n >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(0)}K`;
  return `$${n}`;
};

export default function Pools() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sortField, setSortField] = useState<'tvl' | 'apy' | 'volume'>('tvl');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [selectedPool, setSelectedPool] = useState<typeof allPools[0] | null>(null);
  const [depositAmount, setDepositAmount] = useState('');
  const [autoCompound, setAutoCompound] = useState(true);

  const filtered = allPools
    .filter((p) => {
      const q = search.toLowerCase();
      const matchSearch = !q || p.pair.toLowerCase().includes(q);
      const matchCat = category === 'All' || p.category === category;
      return matchSearch && matchCat;
    })
    .sort((a, b) => {
      const mul = sortDir === 'desc' ? -1 : 1;
      return (a[sortField] - b[sortField]) * mul;
    });

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === 'desc' ? 'asc' : 'desc'));
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  return (
    <Layout>
      <Head>
        <title>Liquidity Pools — LiquidityX</title>
      </Head>

      <div className="py-12 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="text-xs text-neon uppercase tracking-widest font-mono mb-2">Liquidity Pools</div>
          <h1 className="font-display text-4xl md:text-5xl font-700 text-text mb-3">
            Provide liquidity.<br />
            <span className="gradient-text-neon">Earn yield.</span>
          </h1>
          <p className="text-text-muted max-w-xl">
            Deposit assets into institutional-grade pools and earn up to 67.8% APY through trading fees and LQX token incentives.
          </p>
        </motion.div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total TVL', value: fmt(allPools.reduce((s, p) => s + p.tvl, 0)), color: 'neon' },
            { label: '24h Volume', value: fmt(allPools.reduce((s, p) => s + p.volume, 0)), color: 'gold' },
            { label: 'Active Pools', value: allPools.length.toString(), color: 'neon' },
            { label: 'Highest APY', value: `${Math.max(...allPools.map((p) => p.apy))}%`, color: 'gold' },
          ].map((s) => (
            <div key={s.label} className="stat-card">
              <div className="text-xs text-text-muted uppercase tracking-wider mb-2">{s.label}</div>
              <div className={`font-display font-700 text-2xl ${s.color === 'neon' ? 'text-neon' : 'text-gold'}`}>
                {s.value}
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
            <input
              type="text"
              placeholder="Search pool or token..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-field pl-10"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-500 whitespace-nowrap transition-all ${
                  category === cat
                    ? 'bg-neon text-background font-700'
                    : 'bg-surface border border-border text-text-muted hover:text-text hover:border-neon/30'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Pool table */}
        <div className="bg-surface border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Pool</th>
                  <th>
                    <button onClick={() => toggleSort('tvl')} className="flex items-center gap-1 hover:text-neon transition-colors">
                      TVL <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th>
                    <button onClick={() => toggleSort('volume')} className="flex items-center gap-1 hover:text-neon transition-colors">
                      24h Volume <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th>
                    <button onClick={() => toggleSort('apy')} className="flex items-center gap-1 hover:text-neon transition-colors">
                      APY <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th>Spread</th>
                  <th>Category</th>
                  <th>Auto-Compound</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((pool, i) => (
                  <motion.tr
                    key={pool.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="cursor-pointer"
                    onClick={() => setSelectedPool(pool)}
                  >
                    <td className="text-text-muted font-mono text-xs">{pool.id}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="flex -space-x-1">
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 border border-background text-[8px] flex items-center justify-center font-700 text-white">
                            {pool.token0[0]}
                          </div>
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 border border-background text-[8px] flex items-center justify-center font-700 text-white">
                            {pool.token1[0]}
                          </div>
                        </div>
                        <span className="font-mono font-600 text-text">{pool.pair}</span>
                        <span className="text-xs text-text-muted bg-surface-3 px-1.5 py-0.5 rounded">{pool.fee}%</span>
                      </div>
                    </td>
                    <td className="font-mono text-text">{fmt(pool.tvl)}</td>
                    <td className="font-mono text-text-muted">{fmt(pool.volume)}</td>
                    <td>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-neon" />
                        <span className="font-mono font-700 text-neon">{pool.apy}%</span>
                      </div>
                    </td>
                    <td><span className="badge-neutral">{pool.spread}%</span></td>
                    <td>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-surface-3 text-text-muted">
                        {pool.category}
                      </span>
                    </td>
                    <td>
                      <div className={`w-4 h-4 rounded-full border ${pool.autoCompound ? 'bg-neon border-neon' : 'border-border'}`}>
                        {pool.autoCompound && (
                          <svg viewBox="0 0 16 16" fill="none" className="w-full h-full">
                            <path d="M4 8l3 3 5-5" stroke="#0A0A0A" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        )}
                      </div>
                    </td>
                    <td onClick={(e) => { e.stopPropagation(); setSelectedPool(pool); }}>
                      <button className="btn-neon text-xs py-1.5 px-4 flex items-center gap-1">
                        <Plus className="w-3 h-3" /> Deposit
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pool detail modal */}
      <AnimatePresence>
        {selectedPool && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedPool(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 30 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg bg-surface border border-border rounded-2xl overflow-hidden"
            >
              {/* Modal header */}
              <div className="flex items-center justify-between p-6 border-b border-border">
                <div className="flex items-center gap-3">
                  <div className="flex -space-x-1">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 border-2 border-surface text-xs flex items-center justify-center font-700 text-white">
                      {selectedPool.token0[0]}
                    </div>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 border-2 border-surface text-xs flex items-center justify-center font-700 text-white">
                      {selectedPool.token1[0]}
                    </div>
                  </div>
                  <div>
                    <div className="font-display font-700 text-text text-xl">{selectedPool.pair}</div>
                    <div className="text-xs text-text-muted">{selectedPool.category} · {selectedPool.fee}% fee</div>
                  </div>
                </div>
                <button onClick={() => setSelectedPool(null)} className="text-text-muted hover:text-text transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 p-6 border-b border-border">
                <div className="text-center">
                  <div className="text-xs text-text-muted mb-1">TVL</div>
                  <div className="font-mono font-700 text-neon">{fmt(selectedPool.tvl)}</div>
                </div>
                <div className="text-center border-x border-border">
                  <div className="text-xs text-text-muted mb-1">APY</div>
                  <div className="font-mono font-700 text-neon">{selectedPool.apy}%</div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-text-muted mb-1">24h Vol</div>
                  <div className="font-mono font-700 text-text">{fmt(selectedPool.volume)}</div>
                </div>
              </div>

              {/* Deposit form */}
              <div className="p-6 space-y-4">
                <div>
                  <label className="text-xs text-text-muted uppercase tracking-wider mb-2 block">Deposit Amount</label>
                  <div className="relative">
                    <input
                      type="number"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      placeholder="0.00"
                      className="input-field pr-20 text-xl font-mono"
                    />
                    <button
                      onClick={() => setDepositAmount('10000')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-neon text-xs font-600 hover:underline"
                    >MAX</button>
                  </div>
                </div>

                {/* Auto-compound toggle */}
                <div className="flex items-center justify-between p-4 bg-surface-2 rounded-xl">
                  <div>
                    <div className="text-sm text-text font-500">Auto-Compound</div>
                    <div className="text-xs text-text-muted">Automatically reinvest earnings</div>
                  </div>
                  <button
                    onClick={() => setAutoCompound(!autoCompound)}
                    className={`w-11 h-6 rounded-full transition-colors relative ${autoCompound ? 'bg-neon' : 'bg-border'}`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-background absolute top-1 transition-all ${autoCompound ? 'left-6' : 'left-1'}`} />
                  </button>
                </div>

                {depositAmount && (
                  <div className="bg-surface-2 rounded-xl p-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-text-muted">Expected Daily Yield</span>
                      <span className="text-neon font-600">
                        ~${((parseFloat(depositAmount) * selectedPool.apy / 100) / 365).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-muted">Expected APY</span>
                      <span className="text-neon font-600">{selectedPool.apy}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-muted">Pool Share</span>
                      <span className="text-text font-mono">
                        {((parseFloat(depositAmount) / selectedPool.tvl) * 100).toFixed(4)}%
                      </span>
                    </div>
                  </div>
                )}

                <button className="btn-neon w-full py-3.5 text-sm font-700">
                  Deposit to {selectedPool.pair}
                </button>
                <button className="btn-outline w-full py-3 text-sm">
                  Withdraw Liquidity
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
