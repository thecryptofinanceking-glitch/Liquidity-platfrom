/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        background: '#0A0A0A',
        surface: '#111111',
        'surface-2': '#161616',
        'surface-3': '#1C1C1C',
        neon: '#00FFB2',
        'neon-dim': '#00CC8E',
        'neon-dark': '#004D35',
        gold: '#D4AF37',
        'gold-dim': '#A8892A',
        'gold-light': '#F0D060',
        border: '#1E1E1E',
        'border-bright': '#2A2A2A',
        muted: '#4A4A4A',
        text: '#E8E8E8',
        'text-muted': '#888888',
        danger: '#FF4444',
        warning: '#FFB800',
        success: '#00FFB2',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        display: ['Outfit', 'Inter', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-neon': 'linear-gradient(135deg, #00FFB2 0%, #00CC8E 100%)',
        'gradient-gold': 'linear-gradient(135deg, #D4AF37 0%, #F0D060 100%)',
        'gradient-dark': 'linear-gradient(180deg, #0A0A0A 0%, #111111 100%)',
        'glow-neon': 'radial-gradient(circle at center, rgba(0,255,178,0.15) 0%, transparent 70%)',
        'glow-gold': 'radial-gradient(circle at center, rgba(212,175,55,0.15) 0%, transparent 70%)',
      },
      boxShadow: {
        'neon': '0 0 20px rgba(0, 255, 178, 0.3)',
        'neon-lg': '0 0 40px rgba(0, 255, 178, 0.4)',
        'neon-sm': '0 0 10px rgba(0, 255, 178, 0.2)',
        'gold': '0 0 20px rgba(212, 175, 55, 0.3)',
        'gold-lg': '0 0 40px rgba(212, 175, 55, 0.4)',
        'inner-border': 'inset 0 0 0 1px rgba(255,255,255,0.05)',
      },
      animation: {
        'pulse-neon': 'pulse-neon 2s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'scan': 'scan 3s linear infinite',
        'counter': 'counter 1s ease-out forwards',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        'pulse-neon': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(0, 255, 178, 0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(0, 255, 178, 0.6)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'scan': {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        'glow': {
          '0%': { textShadow: '0 0 10px rgba(0,255,178,0.5)' },
          '100%': { textShadow: '0 0 30px rgba(0,255,178,0.9), 0 0 60px rgba(0,255,178,0.3)' },
        },
      },
    },
  },
  plugins: [],
};
