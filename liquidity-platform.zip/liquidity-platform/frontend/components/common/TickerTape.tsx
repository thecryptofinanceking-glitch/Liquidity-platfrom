import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const mockTickers = [
  { symbol: 'BTC/USDC', price: '67,423.50', change: '+2.34', up: true },
  { symbol: 'ETH/USDC', price: '3,521.80', change: '+1.87', up: true },
  { symbol: 'ARB/USDC', price: '1.234', change: '-0.45', up: false },
  { symbol: 'OP/USDC', price: '2.876', change: '+3.21', up: true },
  { symbol: 'LINK/USDC', price: '14.23', change: '+0.98', up: true },
  { symbol: 'UNI/USDC', price: '8.45', change: '-1.23', up: false },
  { symbol: 'AAVE/USDC', price: '98.76', change: '+2.11', up: true },
  { symbol: 'CRV/USDC', price: '0.432', change: '-0.87', up: false },
  { symbol: 'LDO/USDC', price: '1.98', change: '+4.56', up: true },
  { symbol: 'GMX/USDC', price: '43.21', change: '+1.34', up: true },
  { symbol: 'TVL', price: '$2.4B', change: '+5.2%', up: true },
  { symbol: 'VOLUME 24H', price: '$890M', change: '+12.3%', up: true },
];

export default function TickerTape() {
  const [tickers] = useState(mockTickers);

  return (
    <div className="bg-surface border-b border-border h-8 overflow-hidden flex items-center z-50 relative">
      <div className="flex-shrink-0 px-4 text-[10px] font-mono text-neon uppercase tracking-widest border-r border-border h-full flex items-center bg-neon/5">
        LIVE
      </div>
      <div className="ticker-wrap flex-1 h-full flex items-center">
        <div className="ticker-content flex items-center gap-0">
          {[...tickers, ...tickers].map((ticker, i) => (
            <span key={i} className="inline-flex items-center gap-2 px-6 text-xs border-r border-border/40 h-full py-1">
              <span className="font-mono text-text-muted font-500">{ticker.symbol}</span>
              <span className="font-mono text-text font-600">{ticker.price}</span>
              <span className={`flex items-center gap-0.5 font-600 ${ticker.up ? 'text-neon' : 'text-danger'}`}>
                {ticker.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {ticker.change}%
              </span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
