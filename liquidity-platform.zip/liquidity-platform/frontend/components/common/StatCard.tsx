import { motion } from 'framer-motion';
import { ReactNode } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  change?: string;
  changeUp?: boolean;
  icon?: ReactNode;
  accent?: 'neon' | 'gold';
  className?: string;
  suffix?: string;
}

export default function StatCard({
  label,
  value,
  change,
  changeUp,
  icon,
  accent = 'neon',
  className = '',
  suffix,
}: StatCardProps) {
  const accentColor = accent === 'neon' ? '#00FFB2' : '#D4AF37';
  const accentClass = accent === 'neon' ? 'text-neon' : 'text-gold';
  const accentBg = accent === 'neon' ? 'bg-neon/5' : 'bg-gold/5';
  const accentBorder = accent === 'neon' ? 'border-neon/10' : 'border-gold/10';

  return (
    <motion.div
      className={`stat-card group ${className}`}
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      {/* Top row */}
      <div className="flex items-start justify-between mb-4">
        <div className="text-xs text-text-muted uppercase tracking-widest font-500">{label}</div>
        {icon && (
          <div className={`w-9 h-9 rounded-lg ${accentBg} border ${accentBorder} flex items-center justify-center`}>
            <div className={accentClass}>{icon}</div>
          </div>
        )}
      </div>

      {/* Value */}
      <div className={`font-display text-3xl font-700 ${accentClass} mb-2`}>
        {value}
        {suffix && <span className="text-lg text-text-muted ml-1">{suffix}</span>}
      </div>

      {/* Change */}
      {change !== undefined && (
        <div className="flex items-center gap-1.5">
          {changeUp !== undefined ? (
            changeUp ? (
              <TrendingUp className="w-3.5 h-3.5 text-neon" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5 text-danger" />
            )
          ) : null}
          <span className={`text-xs font-600 ${changeUp === undefined ? 'text-text-muted' : changeUp ? 'text-neon' : 'text-danger'}`}>
            {change}
          </span>
          <span className="text-xs text-text-muted">24h</span>
        </div>
      )}

      {/* Decorative corner */}
      <div
        className="absolute top-0 right-0 w-16 h-16 opacity-5 rounded-bl-full"
        style={{ background: `radial-gradient(circle at top right, ${accentColor}, transparent)` }}
      />
    </motion.div>
  );
}
