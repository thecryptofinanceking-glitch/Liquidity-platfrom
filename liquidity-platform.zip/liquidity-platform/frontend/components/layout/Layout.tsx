import { ReactNode } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import TickerTape from '../common/TickerTape';
import { Toaster } from 'react-hot-toast';

interface LayoutProps {
  children: ReactNode;
  fullWidth?: boolean;
  noFooter?: boolean;
}

export default function Layout({ children, fullWidth = false, noFooter = false }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#111111',
            color: '#E8E8E8',
            border: '1px solid #1E1E1E',
            borderRadius: '10px',
          },
          success: { iconTheme: { primary: '#00FFB2', secondary: '#0A0A0A' } },
          error: { iconTheme: { primary: '#FF4444', secondary: '#0A0A0A' } },
        }}
      />
      <TickerTape />
      <Navbar />
      <main className={`flex-1 pt-16 ${!fullWidth ? '' : ''}`}>
        {children}
      </main>
      {!noFooter && <Footer />}
    </div>
  );
}
