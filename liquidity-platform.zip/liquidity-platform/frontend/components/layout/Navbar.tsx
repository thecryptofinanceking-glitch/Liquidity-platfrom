import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown, Zap, BarChart3, Repeat2, Coins, Shield } from 'lucide-react';

const navItems = [
  {
    label: 'Pools',
    href: '/pools',
    icon: BarChart3,
    sub: [
      { label: 'All Pools', href: '/pools' },
      { label: 'My Positions', href: '/pools/positions' },
    ],
  },
  {
    label: 'Market Making',
    href: '/market-making',
    icon: Repeat2,
  },
  {
    label: 'Buyback',
    href: '/buyback',
    icon: Zap,
  },
  {
    label: 'Token',
    href: '/token',
    icon: Coins,
  },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (href: string) =>
    router.pathname === href || router.pathname.startsWith(href + '/');

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/95 backdrop-blur-xl border-b border-border shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
              <div className="w-8 h-8 rounded-lg bg-neon flex items-center justify-center">
                <Zap className="w-5 h-5 text-background" />
              </div>
              <div className="absolute inset-0 rounded-lg bg-neon blur-sm opacity-40 group-hover:opacity-70 transition-opacity" />
            </div>
            <div>
              <span className="font-display font-800 text-lg text-text tracking-tight">
                LIQUIDITY<span className="text-neon">X</span>
              </span>
              <div className="text-[9px] text-text-muted font-mono tracking-widest uppercase leading-none">
                Institutional Grade
              </div>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <div
                key={item.href}
                className="relative"
                onMouseEnter={() => item.sub && setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href={item.href}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive(item.href)
                      ? 'text-neon bg-neon/5'
                      : 'text-text-muted hover:text-text hover:bg-surface'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                  {item.sub && (
                    <ChevronDown className="w-3 h-3 opacity-50" />
                  )}
                </Link>
                {item.sub && (
                  <AnimatePresence>
                    {activeDropdown === item.label && (
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8 }}
                        className="absolute top-full left-0 mt-1 w-48 bg-surface border border-border rounded-xl overflow-hidden shadow-xl"
                      >
                        {item.sub.map((s) => (
                          <Link
                            key={s.href}
                            href={s.href}
                            className="block px-4 py-3 text-sm text-text-muted hover:text-neon hover:bg-surface-2 transition-colors"
                          >
                            {s.label}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                )}
              </div>
            ))}
          </div>

          {/* Right side */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/dashboard"
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-text-muted hover:text-text transition-colors"
            >
              Dashboard
            </Link>
            <WalletButton />
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg text-text-muted hover:text-text hover:bg-surface transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background/98 backdrop-blur-xl border-b border-border"
          >
            <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? 'text-neon bg-neon/5'
                      : 'text-text-muted hover:text-text hover:bg-surface'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}
              <div className="border-t border-border mt-2 pt-2">
                <Link href="/dashboard" onClick={() => setMobileOpen(false)} className="block px-4 py-3 text-sm text-text-muted hover:text-text transition-colors">
                  Dashboard
                </Link>
                <div className="px-4 pt-2"><WalletButton /></div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

function WalletButton() {
  const [connected, setConnected] = useState(false);
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);

  const connect = async () => {
    setLoading(true);
    try {
      if (typeof window !== 'undefined' && (window as any).ethereum) {
        const accounts = await (window as any).ethereum.request({
          method: 'eth_requestAccounts',
        });
        setAddress(accounts[0]);
        setConnected(true);
      } else {
        alert('Please install MetaMask to connect your wallet');
      }
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const disconnect = () => {
    setConnected(false);
    setAddress('');
  };

  if (connected && address) {
    return (
      <button
        onClick={disconnect}
        className="flex items-center gap-2 px-4 py-2 bg-neon/10 border border-neon/30 rounded-lg text-neon text-sm font-medium hover:bg-neon/20 transition-all"
      >
        <div className="w-2 h-2 rounded-full bg-neon animate-pulse" />
        {address.slice(0, 6)}...{address.slice(-4)}
      </button>
    );
  }

  return (
    <button
      onClick={connect}
      disabled={loading}
      className="btn-neon text-sm py-2 px-5 flex items-center gap-2"
    >
      {loading ? (
        <><div className="loader w-4 h-4" /> Connecting...</>
      ) : (
        <>Connect Wallet</>
      )}
    </button>
  );
}
