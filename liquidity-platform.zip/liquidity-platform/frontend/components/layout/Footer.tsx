import Link from 'next/link';
import { Zap, Twitter, Github, MessageCircle, ExternalLink } from 'lucide-react';

const links = {
  Platform: [
    { label: 'Liquidity Pools', href: '/pools' },
    { label: 'Market Making', href: '/market-making' },
    { label: 'Buyback System', href: '/buyback' },
    { label: 'Token Utility', href: '/token' },
    { label: 'Dashboard', href: '/dashboard' },
  ],
  Developers: [
    { label: 'Documentation', href: '/docs' },
    { label: 'API Reference', href: '/api-docs' },
    { label: 'Smart Contracts', href: '/contracts' },
    { label: 'GitHub', href: 'https://github.com/liquidityx', external: true },
    { label: 'Bug Bounty', href: '/bug-bounty' },
  ],
  Company: [
    { label: 'About', href: '/about' },
    { label: 'Blog', href: '/blog' },
    { label: 'Careers', href: '/careers' },
    { label: 'Press Kit', href: '/press' },
    { label: 'Contact', href: '/contact' },
  ],
  Legal: [
    { label: 'Terms of Service', href: '/terms' },
    { label: 'Privacy Policy', href: '/privacy' },
    { label: 'Risk Disclosure', href: '/risk' },
    { label: 'Cookie Policy', href: '/cookies' },
  ],
};

const stats = [
  { label: 'Total Value Locked', value: '$2.4B+' },
  { label: 'Daily Volume', value: '$890M+' },
  { label: 'Active Pools', value: '47' },
  { label: 'Market Pairs', value: '120+' },
];

export default function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      {/* Stats bar */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-display font-700 gradient-text-neon">{stat.value}</div>
                <div className="text-xs text-text-muted mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-6 gap-10">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-3 group mb-4 w-fit">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-neon flex items-center justify-center">
                  <Zap className="w-6 h-6 text-background" />
                </div>
                <div className="absolute inset-0 rounded-xl bg-neon blur-md opacity-30" />
              </div>
              <div>
                <div className="font-display font-800 text-xl text-text">
                  LIQUIDITY<span className="text-neon">X</span>
                </div>
                <div className="text-[9px] text-text-muted font-mono tracking-widest uppercase">
                  Institutional Grade
                </div>
              </div>
            </Link>
            <p className="text-sm text-text-muted leading-relaxed mb-6 max-w-xs">
              Institutional-grade liquidity infrastructure for digital assets. Deep liquidity. Tight spreads. Intelligent execution.
            </p>
            <div className="flex items-center gap-3">
              {[
                { icon: Twitter, href: 'https://twitter.com/liquidityx' },
                { icon: Github, href: 'https://github.com/liquidityx' },
                { icon: MessageCircle, href: 'https://discord.gg/liquidityx' },
              ].map(({ icon: Icon, href }) => (
                <a
                  key={href}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-lg bg-surface border border-border flex items-center justify-center text-text-muted hover:text-neon hover:border-neon/30 hover:bg-neon/5 transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <div className="text-xs font-600 text-text-muted uppercase tracking-widest mb-4">
                {category}
              </div>
              <ul className="space-y-2.5">
                {items.map((item) => (
                  <li key={item.label}>
                    {'external' in item && item.external ? (
                      <a
                        href={item.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-sm text-text-muted hover:text-neon transition-colors"
                      >
                        {item.label}
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <Link
                        href={item.href}
                        className="text-sm text-text-muted hover:text-neon transition-colors"
                      >
                        {item.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="gradient-line my-10" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-xs text-text-muted">
            © 2025 LiquidityX. All rights reserved. Not financial advice.
          </div>
          <div className="flex items-center gap-4 text-xs text-text-muted">
            <span className="flex items-center gap-1.5">
              <div className="status-dot-active" />
              All systems operational
            </span>
            <span>Protocol v3.2.1</span>
            <span>Audited by Certik & Trail of Bits</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
