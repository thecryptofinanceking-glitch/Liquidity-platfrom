// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title StakingContract
 * @notice Stake LQX tokens to earn protocol revenue share and governance rights
 * @dev Supports multiple lock periods with tiered APY rewards
 */
contract StakingContract is ReentrancyGuard, AccessControl, Pausable {
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    bytes32 public constant DISTRIBUTOR_ROLE = keccak256("DISTRIBUTOR_ROLE");

    IERC20 public immutable lqxToken;
    IERC20 public immutable rewardToken; // USDC

    // Staking tiers based on amount
    struct Tier {
        uint256 minStake;
        uint256 apyBps;       // Basis points (100 = 1%)
        string name;
    }

    Tier[] public tiers;

    struct StakeInfo {
        uint256 amount;
        uint256 stakedAt;
        uint256 lockPeriod;   // in seconds
        uint256 lastClaimed;
        uint256 pendingRewards;
        uint8 tierId;
    }

    mapping(address => StakeInfo[]) public stakes;
    mapping(address => uint256) public totalStaked;

    uint256 public totalStakedProtocol;
    uint256 public rewardPool;
    uint256 public totalRewardsDistributed;
    uint256 public rewardPerTokenStored;
    uint256 public lastUpdateTime;

    mapping(address => uint256) public userRewardPerTokenPaid;
    mapping(address => uint256) public rewards;

    // Lock period options
    uint256[] public lockPeriods = [0, 30 days, 90 days, 365 days];
    uint256[] public lockBonusBps = [0, 1000, 2500, 5000]; // 0%, 10%, 25%, 50% bonus

    event Staked(address indexed user, uint256 amount, uint256 lockPeriod, uint8 tierId);
    event Unstaked(address indexed user, uint256 amount, uint256 stakeIndex);
    event RewardsClaimed(address indexed user, uint256 amount);
    event RewardsAdded(uint256 amount);
    event TierAdded(string name, uint256 minStake, uint256 apyBps);

    error LockPeriodNotExpired();
    error InvalidStakeIndex();
    error InvalidLockPeriod();
    error ZeroAmount();
    error InsufficientRewards();

    constructor(address _lqxToken, address _rewardToken, address _admin) {
        lqxToken = IERC20(_lqxToken);
        rewardToken = IERC20(_rewardToken);
        _grantRole(DEFAULT_ADMIN_ROLE, _admin);
        _grantRole(ADMIN_ROLE, _admin);
        _grantRole(DISTRIBUTOR_ROLE, _admin);

        // Initialize tiers
        tiers.push(Tier({ minStake: 1_000 * 1e18, apyBps: 3500, name: "Bronze" }));
        tiers.push(Tier({ minStake: 10_000 * 1e18, apyBps: 5200, name: "Silver" }));
        tiers.push(Tier({ minStake: 50_000 * 1e18, apyBps: 6700, name: "Gold" }));
        tiers.push(Tier({ minStake: 200_000 * 1e18, apyBps: 8900, name: "Platinum" }));
    }

    // ─── View Functions ───────────────────────────────────────────────────────

    function getTier(uint256 amount) public view returns (uint8 tierId) {
        for (uint8 i = uint8(tiers.length) - 1; i >= 0; i--) {
            if (amount >= tiers[i].minStake) {
                return i;
            }
            if (i == 0) break;
        }
        revert("Below minimum stake");
    }

    function getStakes(address user) external view returns (StakeInfo[] memory) {
        return stakes[user];
    }

    function getPendingRewards(address user) public view returns (uint256) {
        return rewards[user] + _earned(user);
    }

    function _earned(address user) internal view returns (uint256) {
        if (totalStakedProtocol == 0) return 0;
        return (totalStaked[user] * (rewardPerToken() - userRewardPerTokenPaid[user])) / 1e18;
    }

    function rewardPerToken() public view returns (uint256) {
        if (totalStakedProtocol == 0) return rewardPerTokenStored;
        return rewardPerTokenStored + (
            (block.timestamp - lastUpdateTime) * rewardPool * 1e18 / totalStakedProtocol / 365 days
        );
    }

    // ─── Stake ────────────────────────────────────────────────────────────────

    /**
     * @notice Stake LQX tokens
     * @param amount Amount of LQX to stake
     * @param lockPeriodIndex Index into lockPeriods array (0=flexible, 1=30d, 2=90d, 3=1yr)
     */
    function stake(uint256 amount, uint8 lockPeriodIndex) external nonReentrant whenNotPaused {
        if (amount == 0) revert ZeroAmount();
        if (lockPeriodIndex >= lockPeriods.length) revert InvalidLockPeriod();

        _updateReward(msg.sender);

        uint8 tierId = getTier(amount);
        uint256 lockPeriod = lockPeriods[lockPeriodIndex];
        uint256 bonusBps = lockBonusBps[lockPeriodIndex];
        uint256 effectiveApyBps = tiers[tierId].apyBps + bonusBps;

        lqxToken.transferFrom(msg.sender, address(this), amount);

        stakes[msg.sender].push(StakeInfo({
            amount: amount,
            stakedAt: block.timestamp,
            lockPeriod: lockPeriod,
            lastClaimed: block.timestamp,
            pendingRewards: 0,
            tierId: tierId
        }));

        totalStaked[msg.sender] += amount;
        totalStakedProtocol += amount;

        emit Staked(msg.sender, amount, lockPeriod, tierId);
    }

    // ─── Unstake ──────────────────────────────────────────────────────────────

    /**
     * @notice Unstake tokens from a specific stake position
     * @param stakeIndex Index in user's stakes array
     */
    function unstake(uint256 stakeIndex) external nonReentrant {
        if (stakeIndex >= stakes[msg.sender].length) revert InvalidStakeIndex();

        StakeInfo storage s = stakes[msg.sender][stakeIndex];
        if (block.timestamp < s.stakedAt + s.lockPeriod) revert LockPeriodNotExpired();

        _updateReward(msg.sender);

        uint256 amount = s.amount;
        uint256 pending = s.pendingRewards;

        totalStaked[msg.sender] -= amount;
        totalStakedProtocol -= amount;

        // Remove stake by swapping with last element
        stakes[msg.sender][stakeIndex] = stakes[msg.sender][stakes[msg.sender].length - 1];
        stakes[msg.sender].pop();

        lqxToken.transfer(msg.sender, amount);
        if (pending > 0) {
            rewardToken.transfer(msg.sender, pending);
            totalRewardsDistributed += pending;
        }

        emit Unstaked(msg.sender, amount, stakeIndex);
    }

    // ─── Claim Rewards ────────────────────────────────────────────────────────

    /**
     * @notice Claim all pending rewards
     */
    function claimRewards() external nonReentrant {
        _updateReward(msg.sender);

        uint256 reward = rewards[msg.sender];
        if (reward == 0) revert InsufficientRewards();
        if (rewardToken.balanceOf(address(this)) < reward) revert InsufficientRewards();

        rewards[msg.sender] = 0;
        totalRewardsDistributed += reward;
        rewardToken.transfer(msg.sender, reward);

        emit RewardsClaimed(msg.sender, reward);
    }

    // ─── Internal ─────────────────────────────────────────────────────────────

    function _updateReward(address user) internal {
        rewardPerTokenStored = rewardPerToken();
        lastUpdateTime = block.timestamp;
        if (user != address(0)) {
            rewards[user] = getPendingRewards(user);
            userRewardPerTokenPaid[user] = rewardPerTokenStored;
        }
    }

    // ─── Admin ────────────────────────────────────────────────────────────────

    /**
     * @notice Add weekly revenue rewards to the pool
     * @param amount USDC amount to distribute
     */
    function addRewards(uint256 amount) external onlyRole(DISTRIBUTOR_ROLE) {
        _updateReward(address(0));
        rewardToken.transferFrom(msg.sender, address(this), amount);
        rewardPool += amount;
        lastUpdateTime = block.timestamp;
        emit RewardsAdded(amount);
    }

    function updateTierApy(uint8 tierId, uint256 newApyBps) external onlyRole(ADMIN_ROLE) {
        require(tierId < tiers.length, "Invalid tier");
        require(newApyBps <= 20000, "APY too high"); // max 200%
        tiers[tierId].apyBps = newApyBps;
    }

    function pause() external onlyRole(ADMIN_ROLE) { _pause(); }
    function unpause() external onlyRole(ADMIN_ROLE) { _unpause(); }

    function emergencyWithdraw(address token, uint256 amount) external onlyRole(DEFAULT_ADMIN_ROLE) {
        IERC20(token).transfer(msg.sender, amount);
    }
}
