// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

interface IUniswapV2Router {
    function swapExactTokensForTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external returns (uint256[] memory amounts);

    function getAmountsOut(uint256 amountIn, address[] calldata path)
        external view returns (uint256[] memory amounts);
}

/**
 * @title BuybackContract
 * @notice Automated LQX token buyback and burn engine
 * @dev Collects trading fees and executes TWAP buybacks to minimize price impact
 */
contract BuybackContract is ReentrancyGuard, AccessControl, Pausable {
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    bytes32 public constant EXECUTOR_ROLE = keccak256("EXECUTOR_ROLE");

    IERC20 public immutable lqxToken;
    IERC20 public immutable usdc;
    IUniswapV2Router public immutable dexRouter;

    address public constant BURN_ADDRESS = address(0x000000000000000000000000000000000000dEaD);

    // Buyback configuration
    uint256 public minBuybackAmount = 1000 * 1e6;   // 1000 USDC minimum
    uint256 public maxSlippageBps = 300;              // 3% max slippage
    uint256 public buybackCooldown = 7 days;
    uint256 public lastBuybackTime;
    uint256 public buybackCycleId;

    // Distribution split when NOT burning
    bool public burnOnly = true;  // If false, partial distribution to stakers
    uint256 public burnBps = 10000; // 100% burn by default
    address public stakingContract;

    // Accounting
    uint256 public totalFeesReceived;
    uint256 public totalLqxBought;
    uint256 public totalLqxBurned;
    uint256 public totalUsdcSpent;

    struct BuybackRecord {
        uint256 cycleId;
        uint256 timestamp;
        uint256 usdcSpent;
        uint256 lqxBought;
        uint256 lqxBurned;
        uint256 avgPrice;
        address executor;
    }

    BuybackRecord[] public buybackHistory;

    event BuybackExecuted(
        uint256 indexed cycleId,
        uint256 usdcSpent,
        uint256 lqxBought,
        uint256 lqxBurned,
        uint256 avgPrice
    );
    event FeesReceived(address indexed pool, uint256 amount, address token);
    event ConfigUpdated(uint256 minAmount, uint256 maxSlippage, uint256 cooldown);

    error CooldownNotElapsed();
    error InsufficientFunds();
    error SlippageExceeded();
    error ZeroAmount();

    constructor(
        address _lqxToken,
        address _usdc,
        address _dexRouter,
        address _admin
    ) {
        lqxToken = IERC20(_lqxToken);
        usdc = IERC20(_usdc);
        dexRouter = IUniswapV2Router(_dexRouter);
        _grantRole(DEFAULT_ADMIN_ROLE, _admin);
        _grantRole(ADMIN_ROLE, _admin);
        _grantRole(EXECUTOR_ROLE, _admin);
    }

    // ─── View Functions ───────────────────────────────────────────────────────

    function getPendingBuybackAmount() external view returns (uint256) {
        return usdc.balanceOf(address(this));
    }

    function canExecuteBuyback() external view returns (bool) {
        return block.timestamp >= lastBuybackTime + buybackCooldown &&
               usdc.balanceOf(address(this)) >= minBuybackAmount;
    }

    function getExpectedLqxOut(uint256 usdcAmount) external view returns (uint256) {
        address[] memory path = new address[](2);
        path[0] = address(usdc);
        path[1] = address(lqxToken);
        try dexRouter.getAmountsOut(usdcAmount, path) returns (uint256[] memory amounts) {
            return amounts[1];
        } catch {
            return 0;
        }
    }

    function getBuybackHistory() external view returns (BuybackRecord[] memory) {
        return buybackHistory;
    }

    function getBuybackCount() external view returns (uint256) {
        return buybackHistory.length;
    }

    // ─── Fee Reception ────────────────────────────────────────────────────────

    /**
     * @notice Receive trading fees from liquidity pools
     * @param amount Amount of fees (in USDC)
     */
    function receiveFees(uint256 amount) external {
        if (amount == 0) revert ZeroAmount();
        usdc.transferFrom(msg.sender, address(this), amount);
        totalFeesReceived += amount;
        emit FeesReceived(msg.sender, amount, address(usdc));
    }

    // ─── Execute Buyback ──────────────────────────────────────────────────────

    /**
     * @notice Execute the buyback — buy LQX from DEX and burn
     * @dev Can be called by EXECUTOR_ROLE or admin
     */
    function executeBuyback() external onlyRole(EXECUTOR_ROLE) nonReentrant whenNotPaused {
        if (block.timestamp < lastBuybackTime + buybackCooldown) revert CooldownNotElapsed();

        uint256 usdcBalance = usdc.balanceOf(address(this));
        if (usdcBalance < minBuybackAmount) revert InsufficientFunds();

        // Use TWAP: execute in chunks if large amount
        uint256 usdcToSpend = usdcBalance;

        // Calculate minimum LQX expected (slippage protection)
        address[] memory path = new address[](2);
        path[0] = address(usdc);
        path[1] = address(lqxToken);

        uint256[] memory expectedAmounts = dexRouter.getAmountsOut(usdcToSpend, path);
        uint256 expectedLqx = expectedAmounts[1];
        uint256 minLqxOut = (expectedLqx * (10000 - maxSlippageBps)) / 10000;

        usdc.approve(address(dexRouter), usdcToSpend);

        uint256[] memory amounts = dexRouter.swapExactTokensForTokens(
            usdcToSpend,
            minLqxOut,
            path,
            address(this),
            block.timestamp + 300
        );

        uint256 lqxBought = amounts[amounts.length - 1];
        uint256 avgPrice = (usdcToSpend * 1e18) / lqxBought; // USDC per LQX in wei

        // Calculate how much to burn vs distribute
        uint256 lqxToBurn = (lqxBought * burnBps) / 10000;
        uint256 lqxToDistribute = lqxBought - lqxToBurn;

        // Burn
        if (lqxToBurn > 0) {
            lqxToken.transfer(BURN_ADDRESS, lqxToBurn);
        }

        // Distribute remainder to stakers
        if (lqxToDistribute > 0 && stakingContract != address(0)) {
            lqxToken.transfer(stakingContract, lqxToDistribute);
        }

        totalLqxBought += lqxBought;
        totalLqxBurned += lqxToBurn;
        totalUsdcSpent += usdcToSpend;
        lastBuybackTime = block.timestamp;
        buybackCycleId++;

        buybackHistory.push(BuybackRecord({
            cycleId: buybackCycleId,
            timestamp: block.timestamp,
            usdcSpent: usdcToSpend,
            lqxBought: lqxBought,
            lqxBurned: lqxToBurn,
            avgPrice: avgPrice,
            executor: msg.sender
        }));

        emit BuybackExecuted(buybackCycleId, usdcToSpend, lqxBought, lqxToBurn, avgPrice);
    }

    /**
     * @notice Emergency manual override — execute buyback with custom params
     */
    function executeBuybackManual(
        uint256 usdcAmount,
        uint256 minLqxOut
    ) external onlyRole(ADMIN_ROLE) nonReentrant {
        if (usdcAmount == 0) revert ZeroAmount();
        if (usdc.balanceOf(address(this)) < usdcAmount) revert InsufficientFunds();

        address[] memory path = new address[](2);
        path[0] = address(usdc);
        path[1] = address(lqxToken);

        usdc.approve(address(dexRouter), usdcAmount);

        uint256[] memory amounts = dexRouter.swapExactTokensForTokens(
            usdcAmount,
            minLqxOut,
            path,
            address(this),
            block.timestamp + 300
        );

        uint256 lqxBought = amounts[amounts.length - 1];
        lqxToken.transfer(BURN_ADDRESS, lqxBought);

        totalLqxBought += lqxBought;
        totalLqxBurned += lqxBought;
        totalUsdcSpent += usdcAmount;
        lastBuybackTime = block.timestamp;
        buybackCycleId++;

        buybackHistory.push(BuybackRecord({
            cycleId: buybackCycleId,
            timestamp: block.timestamp,
            usdcSpent: usdcAmount,
            lqxBought: lqxBought,
            lqxBurned: lqxBought,
            avgPrice: (usdcAmount * 1e18) / lqxBought,
            executor: msg.sender
        }));

        emit BuybackExecuted(buybackCycleId, usdcAmount, lqxBought, lqxBought, (usdcAmount * 1e18) / lqxBought);
    }

    // ─── Admin ────────────────────────────────────────────────────────────────

    function updateConfig(
        uint256 _minAmount,
        uint256 _maxSlippage,
        uint256 _cooldown
    ) external onlyRole(ADMIN_ROLE) {
        require(_maxSlippage <= 1000, "Slippage too high"); // max 10%
        minBuybackAmount = _minAmount;
        maxSlippageBps = _maxSlippage;
        buybackCooldown = _cooldown;
        emit ConfigUpdated(_minAmount, _maxSlippage, _cooldown);
    }

    function setBurnConfig(bool _burnOnly, uint256 _burnBps, address _staking) external onlyRole(ADMIN_ROLE) {
        require(_burnBps <= 10000, "Invalid BPS");
        burnOnly = _burnOnly;
        burnBps = _burnBps;
        stakingContract = _staking;
    }

    function grantExecutorRole(address executor) external onlyRole(ADMIN_ROLE) {
        _grantRole(EXECUTOR_ROLE, executor);
    }

    function pause() external onlyRole(ADMIN_ROLE) { _pause(); }
    function unpause() external onlyRole(ADMIN_ROLE) { _unpause(); }

    function emergencyWithdraw(address token, uint256 amount) external onlyRole(DEFAULT_ADMIN_ROLE) {
        IERC20(token).transfer(msg.sender, amount);
    }
}
