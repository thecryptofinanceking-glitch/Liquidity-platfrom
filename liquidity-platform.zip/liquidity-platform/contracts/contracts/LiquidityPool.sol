// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title LiquidityPool
 * @notice Institutional-grade AMM liquidity pool with auto-compounding and fee collection
 * @dev Implements concentrated liquidity with LP token minting
 */
contract LiquidityPool is ERC20, ReentrancyGuard, AccessControl, Pausable {
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");

    IERC20 public immutable token0;
    IERC20 public immutable token1;

    uint256 public reserve0;
    uint256 public reserve1;

    uint256 public constant FEE_DENOMINATOR = 10000;
    uint256 public tradingFee = 30; // 0.3% default

    uint256 public totalFeesToken0;
    uint256 public totalFeesToken1;

    uint256 public buybackAllocation = 4000;  // 40% of fees
    uint256 public stakersAllocation = 6000;  // 60% of fees
    address public buybackContract;
    address public stakingContract;

    // Auto-compound
    mapping(address => bool) public autoCompound;
    mapping(address => uint256) public pendingRewards0;
    mapping(address => uint256) public pendingRewards1;

    // Deposit tracking
    mapping(address => uint256) public depositedAt;

    event Deposit(address indexed user, uint256 amount0, uint256 amount1, uint256 lpTokensMinted);
    event Withdraw(address indexed user, uint256 lpTokensBurned, uint256 amount0, uint256 amount1);
    event Swap(address indexed user, address tokenIn, uint256 amountIn, uint256 amountOut);
    event FeesCollected(uint256 fee0, uint256 fee1);
    event AutoCompoundToggled(address indexed user, bool enabled);
    event RewardsClaimed(address indexed user, uint256 reward0, uint256 reward1);
    event FeeUpdated(uint256 newFee);

    error InsufficientLiquidity();
    error InsufficientAmount();
    error InvalidToken();
    error SlippageExceeded();
    error ZeroAmount();
    error Unauthorized();

    constructor(
        address _token0,
        address _token1,
        string memory _name,
        string memory _symbol,
        address _admin
    ) ERC20(_name, _symbol) {
        token0 = IERC20(_token0);
        token1 = IERC20(_token1);
        _grantRole(DEFAULT_ADMIN_ROLE, _admin);
        _grantRole(ADMIN_ROLE, _admin);
        _grantRole(OPERATOR_ROLE, _admin);
    }

    // ─── View Functions ───────────────────────────────────────────────────────

    function getReserves() external view returns (uint256 _reserve0, uint256 _reserve1) {
        return (reserve0, reserve1);
    }

    function getAmountOut(
        uint256 amountIn,
        uint256 reserveIn,
        uint256 reserveOut
    ) public view returns (uint256 amountOut) {
        if (amountIn == 0) revert ZeroAmount();
        if (reserveIn == 0 || reserveOut == 0) revert InsufficientLiquidity();
        uint256 amountInWithFee = amountIn * (FEE_DENOMINATOR - tradingFee);
        uint256 numerator = amountInWithFee * reserveOut;
        uint256 denominator = reserveIn * FEE_DENOMINATOR + amountInWithFee;
        amountOut = numerator / denominator;
    }

    function getLpValue(address user) external view returns (uint256 value0, uint256 value1) {
        uint256 supply = totalSupply();
        if (supply == 0) return (0, 0);
        uint256 lpBal = balanceOf(user);
        value0 = (lpBal * reserve0) / supply;
        value1 = (lpBal * reserve1) / supply;
    }

    // ─── Deposit ──────────────────────────────────────────────────────────────

    /**
     * @notice Add liquidity to the pool
     * @param amount0Desired Desired amount of token0 to deposit
     * @param amount1Desired Desired amount of token1 to deposit
     * @param amount0Min Minimum acceptable amount0 (slippage protection)
     * @param amount1Min Minimum acceptable amount1 (slippage protection)
     */
    function deposit(
        uint256 amount0Desired,
        uint256 amount1Desired,
        uint256 amount0Min,
        uint256 amount1Min
    ) external nonReentrant whenNotPaused returns (uint256 lpTokens) {
        if (amount0Desired == 0 || amount1Desired == 0) revert ZeroAmount();

        uint256 amount0;
        uint256 amount1;
        uint256 supply = totalSupply();

        if (supply == 0) {
            amount0 = amount0Desired;
            amount1 = amount1Desired;
            lpTokens = _sqrt(amount0 * amount1);
        } else {
            uint256 amount1Optimal = (amount0Desired * reserve1) / reserve0;
            if (amount1Optimal <= amount1Desired) {
                if (amount1Optimal < amount1Min) revert SlippageExceeded();
                amount0 = amount0Desired;
                amount1 = amount1Optimal;
            } else {
                uint256 amount0Optimal = (amount1Desired * reserve0) / reserve1;
                if (amount0Optimal < amount0Min) revert SlippageExceeded();
                amount0 = amount0Optimal;
                amount1 = amount1Desired;
            }
            lpTokens = _min(
                (amount0 * supply) / reserve0,
                (amount1 * supply) / reserve1
            );
        }

        if (lpTokens == 0) revert InsufficientAmount();

        token0.transferFrom(msg.sender, address(this), amount0);
        token1.transferFrom(msg.sender, address(this), amount1);

        reserve0 += amount0;
        reserve1 += amount1;
        depositedAt[msg.sender] = block.timestamp;

        _mint(msg.sender, lpTokens);

        emit Deposit(msg.sender, amount0, amount1, lpTokens);
    }

    // ─── Withdraw ─────────────────────────────────────────────────────────────

    /**
     * @notice Remove liquidity from the pool
     * @param lpTokens Amount of LP tokens to burn
     * @param amount0Min Minimum token0 to receive
     * @param amount1Min Minimum token1 to receive
     */
    function withdraw(
        uint256 lpTokens,
        uint256 amount0Min,
        uint256 amount1Min
    ) external nonReentrant whenNotPaused returns (uint256 amount0, uint256 amount1) {
        if (lpTokens == 0) revert ZeroAmount();
        if (balanceOf(msg.sender) < lpTokens) revert InsufficientLiquidity();

        uint256 supply = totalSupply();
        amount0 = (lpTokens * reserve0) / supply;
        amount1 = (lpTokens * reserve1) / supply;

        if (amount0 < amount0Min || amount1 < amount1Min) revert SlippageExceeded();

        _burn(msg.sender, lpTokens);
        reserve0 -= amount0;
        reserve1 -= amount1;

        // Claim pending rewards before withdrawal
        _distributePendingRewards(msg.sender);

        token0.transfer(msg.sender, amount0);
        token1.transfer(msg.sender, amount1);

        emit Withdraw(msg.sender, lpTokens, amount0, amount1);
    }

    // ─── Swap ─────────────────────────────────────────────────────────────────

    /**
     * @notice Swap tokens through the pool
     * @param tokenIn Address of input token
     * @param amountIn Input amount
     * @param amountOutMin Minimum output (slippage protection)
     */
    function swap(
        address tokenIn,
        uint256 amountIn,
        uint256 amountOutMin
    ) external nonReentrant whenNotPaused returns (uint256 amountOut) {
        if (amountIn == 0) revert ZeroAmount();

        bool isToken0In = tokenIn == address(token0);
        if (!isToken0In && tokenIn != address(token1)) revert InvalidToken();

        (uint256 reserveIn, uint256 reserveOut) = isToken0In
            ? (reserve0, reserve1)
            : (reserve1, reserve0);

        amountOut = getAmountOut(amountIn, reserveIn, reserveOut);
        if (amountOut < amountOutMin) revert SlippageExceeded();

        // Collect fee
        uint256 feeAmount = (amountIn * tradingFee) / FEE_DENOMINATOR;
        _distributeFees(isToken0In ? feeAmount : 0, isToken0In ? 0 : feeAmount);

        // Transfer tokens
        IERC20(tokenIn).transferFrom(msg.sender, address(this), amountIn);
        if (isToken0In) {
            token1.transfer(msg.sender, amountOut);
            reserve0 += amountIn - feeAmount;
            reserve1 -= amountOut;
        } else {
            token0.transfer(msg.sender, amountOut);
            reserve1 += amountIn - feeAmount;
            reserve0 -= amountOut;
        }

        emit Swap(msg.sender, tokenIn, amountIn, amountOut);
    }

    // ─── Rewards ──────────────────────────────────────────────────────────────

    /**
     * @notice Claim accumulated trading fee rewards
     */
    function claimRewards() external nonReentrant {
        _distributePendingRewards(msg.sender);
    }

    function toggleAutoCompound() external {
        autoCompound[msg.sender] = !autoCompound[msg.sender];
        emit AutoCompoundToggled(msg.sender, autoCompound[msg.sender]);
    }

    // ─── Internal ─────────────────────────────────────────────────────────────

    function _distributeFees(uint256 fee0, uint256 fee1) internal {
        if (fee0 > 0) {
            uint256 buybackFee0 = (fee0 * buybackAllocation) / FEE_DENOMINATOR;
            uint256 stakerFee0 = fee0 - buybackFee0;
            if (buybackContract != address(0)) {
                token0.transfer(buybackContract, buybackFee0);
            }
            totalFeesToken0 += stakerFee0;
        }
        if (fee1 > 0) {
            uint256 buybackFee1 = (fee1 * buybackAllocation) / FEE_DENOMINATOR;
            uint256 stakerFee1 = fee1 - buybackFee1;
            if (buybackContract != address(0)) {
                token1.transfer(buybackContract, buybackFee1);
            }
            totalFeesToken1 += stakerFee1;
        }
        emit FeesCollected(fee0, fee1);
    }

    function _distributePendingRewards(address user) internal {
        uint256 pending0 = pendingRewards0[user];
        uint256 pending1 = pendingRewards1[user];

        if (pending0 > 0 || pending1 > 0) {
            pendingRewards0[user] = 0;
            pendingRewards1[user] = 0;
            if (pending0 > 0) token0.transfer(user, pending0);
            if (pending1 > 0) token1.transfer(user, pending1);
            emit RewardsClaimed(user, pending0, pending1);
        }
    }

    function _sqrt(uint256 y) internal pure returns (uint256 z) {
        if (y > 3) {
            z = y;
            uint256 x = y / 2 + 1;
            while (x < z) {
                z = x;
                x = (y / x + x) / 2;
            }
        } else if (y != 0) {
            z = 1;
        }
    }

    function _min(uint256 a, uint256 b) internal pure returns (uint256) {
        return a < b ? a : b;
    }

    // ─── Admin ────────────────────────────────────────────────────────────────

    function setTradingFee(uint256 _fee) external onlyRole(ADMIN_ROLE) {
        require(_fee <= 1000, "Fee too high"); // max 10%
        tradingFee = _fee;
        emit FeeUpdated(_fee);
    }

    function setBuybackContract(address _buyback) external onlyRole(ADMIN_ROLE) {
        buybackContract = _buyback;
    }

    function setStakingContract(address _staking) external onlyRole(ADMIN_ROLE) {
        stakingContract = _staking;
    }

    function setAllocation(uint256 _buyback, uint256 _stakers) external onlyRole(ADMIN_ROLE) {
        require(_buyback + _stakers == FEE_DENOMINATOR, "Must sum to 10000");
        buybackAllocation = _buyback;
        stakersAllocation = _stakers;
    }

    function pause() external onlyRole(ADMIN_ROLE) { _pause(); }
    function unpause() external onlyRole(ADMIN_ROLE) { _unpause(); }

    function emergencyWithdraw(address token, uint256 amount) external onlyRole(DEFAULT_ADMIN_ROLE) {
        IERC20(token).transfer(msg.sender, amount);
    }
}
