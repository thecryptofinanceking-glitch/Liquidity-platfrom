const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  console.log("🚀 Deploying LiquidityX Protocol...\n");

  const [deployer] = await ethers.getSigners();
  console.log(`📍 Deployer: ${deployer.address}`);
  console.log(`💰 Balance: ${ethers.formatEther(await ethers.provider.getBalance(deployer.address))} ETH\n`);

  const network = await ethers.provider.getNetwork();
  console.log(`🌐 Network: ${network.name} (chainId: ${network.chainId})\n`);

  // ─── Known token addresses ─────────────────────────────────────────────────
  const TOKEN_ADDRESSES = {
    1: { // Ethereum
      USDC: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
      WBTC: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
      WETH: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
      DEX_ROUTER: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", // Uniswap V2
    },
    42161: { // Arbitrum
      USDC: "0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8",
      WBTC: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
      WETH: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
      DEX_ROUTER: "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506", // SushiSwap
    },
    31337: { // Hardhat local
      USDC: null, // Will deploy mock
      WBTC: null,
      WETH: null,
      DEX_ROUTER: null,
    },
  };

  const chainId = Number(network.chainId);
  const addrs = TOKEN_ADDRESSES[chainId] || TOKEN_ADDRESSES[31337];

  let usdcAddress = addrs.USDC;
  let dexRouterAddress = addrs.DEX_ROUTER;
  let wbtcAddress = addrs.WBTC;
  let wethAddress = addrs.WETH;

  // Deploy mock tokens if local network
  if (chainId === 31337) {
    console.log("📦 Deploying mock tokens for local testing...");

    const MockERC20 = await ethers.getContractFactory("MockERC20");

    const mockUSDC = await MockERC20.deploy("USD Coin", "USDC", 6);
    await mockUSDC.waitForDeployment();
    usdcAddress = await mockUSDC.getAddress();
    console.log(`  USDC: ${usdcAddress}`);

    const mockWBTC = await MockERC20.deploy("Wrapped Bitcoin", "WBTC", 8);
    await mockWBTC.waitForDeployment();
    wbtcAddress = await mockWBTC.getAddress();
    console.log(`  WBTC: ${wbtcAddress}`);

    const mockWETH = await MockERC20.deploy("Wrapped Ether", "WETH", 18);
    await mockWETH.waitForDeployment();
    wethAddress = await mockWETH.getAddress();
    console.log(`  WETH: ${wethAddress}`);

    // For local, use a mock router
    dexRouterAddress = deployer.address; // placeholder
    console.log();
  }

  // ─── Deploy LQX Token ─────────────────────────────────────────────────────
  console.log("🪙  Deploying LQX Token...");
  const LQXToken = await ethers.getContractFactory("LQXToken");
  const lqxToken = await LQXToken.deploy(deployer.address, "10000000000000000000000000"); // 10M
  await lqxToken.waitForDeployment();
  const lqxAddress = await lqxToken.getAddress();
  console.log(`  LQX Token: ${lqxAddress}`);

  // ─── Deploy Liquidity Pools ───────────────────────────────────────────────
  console.log("\n💧 Deploying Liquidity Pools...");

  const LiquidityPool = await ethers.getContractFactory("LiquidityPool");

  const btcPool = await LiquidityPool.deploy(
    wbtcAddress,
    usdcAddress,
    "LiquidityX BTC-USDC LP",
    "LQX-BTC-LP",
    deployer.address
  );
  await btcPool.waitForDeployment();
  const btcPoolAddr = await btcPool.getAddress();
  console.log(`  BTC/USDC Pool: ${btcPoolAddr}`);

  const ethPool = await LiquidityPool.deploy(
    wethAddress,
    usdcAddress,
    "LiquidityX ETH-USDC LP",
    "LQX-ETH-LP",
    deployer.address
  );
  await ethPool.waitForDeployment();
  const ethPoolAddr = await ethPool.getAddress();
  console.log(`  ETH/USDC Pool: ${ethPoolAddr}`);

  // ─── Deploy Staking Contract ──────────────────────────────────────────────
  console.log("\n🔒 Deploying Staking Contract...");
  const StakingContract = await ethers.getContractFactory("StakingContract");
  const staking = await StakingContract.deploy(lqxAddress, usdcAddress, deployer.address);
  await staking.waitForDeployment();
  const stakingAddr = await staking.getAddress();
  console.log(`  Staking: ${stakingAddr}`);

  // ─── Deploy Buyback Contract ──────────────────────────────────────────────
  console.log("\n🔥 Deploying Buyback Contract...");
  const BuybackContract = await ethers.getContractFactory("BuybackContract");
  const buyback = await BuybackContract.deploy(
    lqxAddress,
    usdcAddress,
    dexRouterAddress || deployer.address,
    deployer.address
  );
  await buyback.waitForDeployment();
  const buybackAddr = await buyback.getAddress();
  console.log(`  Buyback: ${buybackAddr}`);

  // ─── Wire contracts together ──────────────────────────────────────────────
  console.log("\n🔗 Configuring contracts...");

  await btcPool.setBuybackContract(buybackAddr);
  await btcPool.setStakingContract(stakingAddr);
  await ethPool.setBuybackContract(buybackAddr);
  await ethPool.setStakingContract(stakingAddr);
  await buyback.setBurnConfig(true, 10000, stakingAddr);

  console.log("  ✅ Contracts wired");

  // ─── Save deployment info ─────────────────────────────────────────────────
  const deployment = {
    network: network.name,
    chainId: Number(network.chainId),
    deployer: deployer.address,
    timestamp: new Date().toISOString(),
    contracts: {
      LQXToken: lqxAddress,
      BTCUSDCPool: btcPoolAddr,
      ETHUSDCPool: ethPoolAddr,
      StakingContract: stakingAddr,
      BuybackContract: buybackAddr,
      USDC: usdcAddress,
      WBTC: wbtcAddress,
      WETH: wethAddress,
    },
  };

  const outputPath = path.join(__dirname, `../deployments/${network.name}.json`);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(deployment, null, 2));

  // Also write .env snippet
  const envSnippet = `
# LiquidityX Deployed Contracts (${network.name} - ${new Date().toISOString()})
NEXT_PUBLIC_CHAIN_ID=${network.chainId}
NEXT_PUBLIC_TOKEN_ADDRESS=${lqxAddress}
NEXT_PUBLIC_BTC_POOL_ADDRESS=${btcPoolAddr}
NEXT_PUBLIC_ETH_POOL_ADDRESS=${ethPoolAddr}
NEXT_PUBLIC_STAKING_ADDRESS=${stakingAddr}
NEXT_PUBLIC_BUYBACK_ADDRESS=${buybackAddr}
`;
  fs.writeFileSync(path.join(__dirname, `../deployments/${network.name}.env`), envSnippet.trim());

  console.log("\n✅ Deployment complete!");
  console.log("\n📋 Summary:");
  console.log("─".repeat(50));
  Object.entries(deployment.contracts).forEach(([name, addr]) => {
    console.log(`  ${name.padEnd(20)} ${addr}`);
  });
  console.log("─".repeat(50));
  console.log(`\n💾 Saved to: deployments/${network.name}.json`);
  console.log(`📝 Env vars: deployments/${network.name}.env`);
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("❌ Deployment failed:", err);
    process.exit(1);
  });
