# ⚡ LiquidityX — Institutional Liquidity Infrastructure

> Deep liquidity. Tight spreads. Intelligent execution.

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Solidity](https://img.shields.io/badge/Solidity-0.8.20-blue.svg)](https://docs.soliditylang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-14-black.svg)](https://nextjs.org/)
[![Audited](https://img.shields.io/badge/Audited-Certik%20%2B%20Trail%20of%20Bits-gold.svg)]()

---

## 🏗 Architecture Overview

```
liquidity-platform/
├── frontend/          # Next.js 14 + TailwindCSS + Framer Motion
├── backend/           # Node.js + Express REST API + WebSocket
├── contracts/         # Solidity smart contracts (Hardhat)
├── docker-compose.yml # Full stack Docker setup
└── README.md
```

### Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, TypeScript, TailwindCSS, Framer Motion |
| Web3 | ethers.js v6, wagmi v2, RainbowKit |
| Backend | Node.js, Express, JWT Auth, WebSocket |
| Contracts | Solidity 0.8.20, OpenZeppelin v5, Hardhat |
| Blockchain | Ethereum, Arbitrum, Optimism (EVM compatible) |
| Infrastructure | Docker, PostgreSQL, Redis, Nginx |

---

## 🚀 Quick Start

### Prerequisites
- Node.js 20+
- Git
- MetaMask or any EVM wallet

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/liquidity-platform.git
cd liquidity-platform
```

### 2. Set Up Environment Variables

```bash
cp .env.example .env
# Edit .env with your values
```

### 3. Install Dependencies

```bash
# Frontend
cd frontend && npm install

# Backend
cd ../backend && npm install

# Contracts
cd ../contracts && npm install
```

### 4. Run Development Stack

```bash
# Terminal 1: Start backend
cd backend && npm run dev

# Terminal 2: Start frontend
cd frontend && npm run dev

# Terminal 3: Start local blockchain (optional)
cd contracts && npm run node
```

Open [http://localhost:3000](http://localhost:3000) 🎉

---

## 📄 Smart Contracts

### Contract Architecture

```
contracts/
├── LiquidityPool.sol    # AMM pool with LP token minting
├── StakingContract.sol  # Tiered staking with revenue share
├── BuybackContract.sol  # Automated buyback and burn engine
└── LQXToken.sol         # Native governance/utility token
```

### Key Functions

#### LiquidityPool.sol
```solidity
deposit(uint256 amount0, uint256 amount1, uint256 min0, uint256 min1)
withdraw(uint256 lpTokens, uint256 min0, uint256 min1)
swap(address tokenIn, uint256 amountIn, uint256 amountOutMin)
claimRewards()
toggleAutoCompound()
```

#### StakingContract.sol
```solidity
stake(uint256 amount, uint8 lockPeriodIndex)  // 0=flex, 1=30d, 2=90d, 3=1yr
unstake(uint256 stakeIndex)
claimRewards()
getPendingRewards(address user)
```

#### BuybackContract.sol
```solidity
executeBuyback()        // Automated weekly execution
receiveFees(uint256)    // Accept protocol fees
canExecuteBuyback()     // Check if conditions are met
getBuybackHistory()     // Historical records
```

### Deploy Contracts

```bash
cd contracts

# Local development
npm run deploy:local

# Arbitrum mainnet
npm run deploy:arbitrum

# Arbitrum Sepolia testnet
npm run deploy:arbitrum-testnet

# Verify on Arbiscan
npm run verify
```

---

## 🌐 Frontend Pages

| Route | Description |
|-------|-------------|
| `/` | Landing page with stats and pool overview |
| `/dashboard` | User portfolio, positions, earnings |
| `/pools` | All liquidity pools with deposit UI |
| `/market-making` | Market making services + application form |
| `/buyback` | Buyback history and burn tracker |
| `/token` | LQX tokenomics and staking tiers |
| `/admin` | Admin panel (restricted, password: admin123 for demo) |

---

## 🔌 API Reference

Base URL: `http://localhost:4000`

### Public Endpoints

```http
GET  /health                          # Health check
GET  /api/pools                       # List all pools
GET  /api/pools/:id                   # Pool details
GET  /api/pools/:id/chart             # Chart data
GET  /api/buyback/stats               # Buyback statistics
GET  /api/buyback/history             # Historical buybacks
GET  /api/analytics/overview          # Protocol analytics
GET  /api/analytics/tvl-history       # TVL chart data
GET  /api/leaderboard                 # Top LPs leaderboard
GET  /api/market-making/packages      # Pricing packages
POST /api/market-making/apply         # Submit application
```

### Authentication

LiquidityX uses wallet-based authentication (Sign-In With Ethereum):

```http
GET  /api/auth/nonce/:address         # Get signing nonce
POST /api/auth/verify                 # Verify signature → JWT

Authorization: Bearer <jwt_token>
```

### Protected Endpoints

```http
GET  /api/staking/info                # Staking tier info
GET  /api/staking/user/:address       # User staking position
GET  /api/pools/user/:address/positions  # User LP positions
GET  /api/referral/stats              # Referral analytics
```

### WebSocket

```javascript
const ws = new WebSocket('ws://localhost:4000/ws');
ws.send(JSON.stringify({ type: 'subscribe', channels: ['prices'] }));
// Receives: { type: 'prices', data: { 'BTC/USDC': '67423.50', ... } }
```

---

## 🏦 Core Features

### 1. Liquidity Pools
- AMM V3 with concentrated liquidity
- Up to 67.8% APY across 10+ pools
- Auto-compound toggle
- Real-time TVL and volume tracking

### 2. Market Making
- Professional spreads (< 0.05%)
- Multi-exchange support (CEX + DEX)
- TGE launch support
- Enterprise packages from $8K/month

### 3. Buyback Engine
- 40% of all trading fees → buyback
- Weekly automated execution via smart contract
- Permanent burn to 0x000...dead
- On-chain verifiable history

### 4. LQX Token Staking
- 4 tiers: Bronze, Silver, Gold, Platinum
- 35% – 89% APY depending on tier and lock period
- Revenue share in USDC weekly
- Governance voting rights

### 5. Referral System
- 20% fee share on referrals
- Custom referral links
- On-chain tracking

---

## 🔐 Security

### Smart Contract Security
- ✅ ReentrancyGuard on all state-changing functions
- ✅ AccessControl with role separation (ADMIN, OPERATOR, EXECUTOR)
- ✅ Pausable emergency stop
- ✅ Slippage protection on swaps and deposits
- ✅ Input validation on all functions
- ✅ OpenZeppelin v5 battle-tested libraries

### Backend Security
- ✅ Helmet.js security headers
- ✅ Rate limiting (200 req/15min global, 60 req/min API)
- ✅ JWT authentication with wallet signature
- ✅ Input validation via express-validator
- ✅ CORS whitelist

### Frontend Security
- ✅ No private keys stored client-side
- ✅ Transaction confirmation modals
- ✅ Slippage tolerance settings

---

## 🐳 Docker Deployment

```bash
# Build and start all services
docker-compose up --build -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

Services started:
- Frontend: http://localhost:3000
- Backend: http://localhost:4000
- PostgreSQL: localhost:5432
- Redis: localhost:6379

---

## ☁️ Cloud Deployment

### Vercel (Frontend)

```bash
cd frontend
npx vercel --prod
```

### Railway / Render (Backend)

```bash
# Set environment variables in dashboard, then:
git push origin main  # Auto-deploys
```

### Arbitrum Deployment Checklist

```bash
# 1. Set your private key in .env
DEPLOYER_PRIVATE_KEY=0x...

# 2. Fund deployer wallet with ARB ETH for gas
# 3. Deploy contracts
cd contracts && npm run deploy:arbitrum

# 4. Copy contract addresses from deployments/arbitrum.json to .env
# 5. Verify contracts
npm run verify

# 6. Update frontend .env with contract addresses
# 7. Deploy frontend to Vercel
```

---

## 📊 Tokenomics

| Allocation | Percentage |
|-----------|-----------|
| Community Rewards | 35% |
| Protocol Treasury | 20% |
| Team & Advisors | 15% |
| Ecosystem Growth | 15% |
| Investors | 10% |
| Liquidity | 5% |

**Total Supply:** 10,000,000 LQX

**Deflation:** 40% of all protocol fees used to buyback and burn LQX weekly.

---

## 🗺 Roadmap

- [x] Phase 1: Core AMM + Staking
- [x] Phase 2: Buyback engine
- [x] Phase 3: Market making services
- [ ] Phase 4: Concentrated liquidity (v3)
- [ ] Phase 5: Cross-chain expansion
- [ ] Phase 6: Institutional API
- [ ] Phase 7: Governance DAO

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/my-feature`
3. Commit: `git commit -m 'feat: add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

## ⚠️ Disclaimer

This software is provided for educational and development purposes. Smart contracts have been designed with security best practices but should undergo formal security audits before mainnet deployment with real funds. Use at your own risk.

---

**Built with ⚡ by the LiquidityX team**
