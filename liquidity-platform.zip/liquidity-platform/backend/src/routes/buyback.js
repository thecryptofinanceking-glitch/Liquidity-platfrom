const express = require('express');
const router = express.Router();

const mockHistory = [
  { cycleId: 147, date: '2025-07-22T00:00:00Z', feesCollected: 312400, lqxBought: 28400, avgPrice: 1.24, burned: 28400, txHash: '0xabc123...' },
  { cycleId: 146, date: '2025-07-15T00:00:00Z', feesCollected: 287900, lqxBought: 24100, avgPrice: 1.19, burned: 24100, txHash: '0xdef456...' },
  { cycleId: 145, date: '2025-07-08T00:00:00Z', feesCollected: 354200, lqxBought: 31200, avgPrice: 1.32, burned: 31200, txHash: '0xghi789...' },
  { cycleId: 144, date: '2025-07-01T00:00:00Z', feesCollected: 241800, lqxBought: 22800, avgPrice: 1.18, burned: 22800, txHash: '0xjkl012...' },
  { cycleId: 143, date: '2025-06-24T00:00:00Z', feesCollected: 298600, lqxBought: 27300, avgPrice: 1.21, burned: 27300, txHash: '0xmno345...' },
];

// GET /api/buyback/stats
router.get('/stats', (req, res) => {
  const totalFeesCollected = mockHistory.reduce((s, r) => s + r.feesCollected, 0);
  const totalBurned = mockHistory.reduce((s, r) => s + r.burned, 0);
  const currentCycle = mockHistory[0].cycleId + 1;
  const nextBuyback = new Date('2025-07-29T00:00:00Z').toISOString();

  res.json({
    success: true,
    data: {
      totalFeesCollected,
      totalBurned,
      totalBurntValue: totalBurned * 1.24,
      currentCycle,
      nextBuyback,
      burnRate: '40%',
      currentBalance: 124800,
      totalSupply: 10_000_000,
      circulatingSupply: 7_900_000,
      burnedSupplyPct: 21,
    },
  });
});

// GET /api/buyback/history
router.get('/history', (req, res) => {
  const { limit = 20, offset = 0 } = req.query;
  const paginated = mockHistory.slice(Number(offset), Number(offset) + Number(limit));
  res.json({
    success: true,
    data: paginated,
    total: mockHistory.length,
  });
});

module.exports = router;
