const express = require('express');
const router = express.Router();

// GET /api/staking/info
router.get('/info', (req, res) => {
  res.json({
    success: true,
    data: {
      tiers: [
        { id: 0, name: 'Bronze', minStake: 1000, apyBps: 3500, color: '#CD7F32' },
        { id: 1, name: 'Silver', minStake: 10000, apyBps: 5200, color: '#C0C0C0' },
        { id: 2, name: 'Gold', minStake: 50000, apyBps: 6700, color: '#D4AF37' },
        { id: 3, name: 'Platinum', minStake: 200000, apyBps: 8900, color: '#00FFB2' },
      ],
      lockPeriods: [
        { label: 'Flexible', days: 0, bonusBps: 0 },
        { label: '30 Days', days: 30, bonusBps: 1000 },
        { label: '90 Days', days: 90, bonusBps: 2500 },
        { label: '1 Year', days: 365, bonusBps: 5000 },
      ],
      totalStaked: 4_200_000,
      rewardPool: 1_870_000,
      nextRewardDistribution: new Date(Date.now() + 3 * 86400000).toISOString(),
    },
  });
});

// GET /api/staking/user/:address
router.get('/user/:address', (req, res) => {
  res.json({
    success: true,
    data: {
      staked: 10000,
      stakingValue: 12400,
      pendingRewards: 324.50,
      tier: 'Silver',
      apy: 52,
      unlockAt: new Date(Date.now() + 18 * 86400000).toISOString(),
    },
  });
});

module.exports = router;
