const express = require('express');
const router = express.Router();

const mockLeaderboard = [
  { rank: 1, address: '0x742d35Cc6634C0532925a3b8D4C1dDf9aBcD1234', ens: 'whale.eth', totalDeposited: 12_400_000, earned: 287_000, pools: 8, since: '2024-01-15' },
  { rank: 2, address: '0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAf2', ens: null, totalDeposited: 8_700_000, earned: 198_000, pools: 5, since: '2024-02-20' },
  { rank: 3, address: '0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d35A', ens: 'provider.eth', totalDeposited: 6_200_000, earned: 142_000, pools: 6, since: '2024-03-01' },
  { rank: 4, address: '0x6E0d01A76C3Cf4288372a29124A26D4353EE51BE', ens: null, totalDeposited: 4_100_000, earned: 94_000, pools: 4, since: '2024-04-11' },
  { rank: 5, address: '0xd4C9b57d17B4Da8F9EFaD0E9d3bdf4dF44C63Bc1', ens: 'defi.eth', totalDeposited: 2_900_000, earned: 67_000, pools: 3, since: '2024-05-08' },
  ...Array.from({ length: 15 }, (_, i) => ({
    rank: i + 6,
    address: `0x${Math.random().toString(16).slice(2, 42).padEnd(40, '0')}`,
    ens: null,
    totalDeposited: Math.round((2_800_000 - i * 150_000) * (0.9 + Math.random() * 0.2)),
    earned: Math.round(60_000 - i * 3000),
    pools: Math.ceil(Math.random() * 4 + 1),
    since: `2024-${String(Math.ceil(Math.random() * 6 + 6)).padStart(2, '0')}-${String(Math.ceil(Math.random() * 28)).padStart(2, '0')}`,
  })),
];

// GET /api/leaderboard
router.get('/', (req, res) => {
  const { limit = 20, offset = 0 } = req.query;
  res.json({
    success: true,
    data: mockLeaderboard.slice(Number(offset), Number(offset) + Number(limit)),
    total: mockLeaderboard.length,
  });
});

module.exports = router;
