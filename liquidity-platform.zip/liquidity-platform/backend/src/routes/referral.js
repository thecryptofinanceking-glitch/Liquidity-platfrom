const express = require('express');
const router = express.Router();

// GET /api/referral/stats
router.get('/stats', (req, res) => {
  const address = req.user?.address;
  res.json({
    success: true,
    data: {
      referralCode: `LQX-${address?.slice(2, 8).toUpperCase() || 'DEMO01'}`,
      referralLink: `https://liquidityx.io/?ref=LQX-${address?.slice(2, 8).toUpperCase() || 'DEMO01'}`,
      totalReferrals: 12,
      activeReferrals: 7,
      totalEarned: 1240.50,
      pendingRewards: 87.30,
      feeSharePct: 20,
      tier: 'Silver Referrer',
    },
  });
});

// POST /api/referral/register
router.post('/register', (req, res) => {
  const { referralCode } = req.body;
  res.json({
    success: true,
    message: `Referral code ${referralCode} applied. You will receive 5% fee reduction.`,
  });
});

module.exports = router;
