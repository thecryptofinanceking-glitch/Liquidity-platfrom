const express = require('express');
const router = express.Router();
const { body, param, query, validationResult } = require('express-validator');
const { authenticate, optionalAuth } = require('../middleware/auth');
const { validateRequest } = require('../middleware/validate');

// Mock data (replace with DB + contract reads)
const mockPools = [
  { id: 1, pair: 'BTC/USDC', token0: '0x2260FAC5E...', token1: '0xA0b86991...', tvl: 423000000, volume24h: 89000000, apy: 18.4, spread: 0.02, fee: 0.3, category: 'Blue Chip', active: true, contract: process.env.BTC_POOL_ADDRESS },
  { id: 2, pair: 'ETH/USDC', token0: '0xC02aaA39...', token1: '0xA0b86991...', tvl: 312000000, volume24h: 134000000, apy: 22.1, spread: 0.03, fee: 0.3, category: 'Blue Chip', active: true, contract: process.env.ETH_POOL_ADDRESS },
  { id: 3, pair: 'ARB/USDC', token0: '0x912CE59...', token1: '0xA0b86991...', tvl: 87000000, volume24h: 45000000, apy: 34.7, spread: 0.05, fee: 0.5, category: 'L2', active: true, contract: process.env.ARB_POOL_ADDRESS },
  { id: 4, pair: 'OP/USDC', token0: '0x4200000...', token1: '0xA0b86991...', tvl: 56000000, volume24h: 23000000, apy: 41.2, spread: 0.06, fee: 0.5, category: 'L2', active: true, contract: process.env.OP_POOL_ADDRESS },
];

/**
 * GET /api/pools
 * Get all active liquidity pools
 */
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { category, sortBy = 'tvl', order = 'desc', limit = 50, offset = 0 } = req.query;

    let pools = [...mockPools];

    if (category && category !== 'All') {
      pools = pools.filter(p => p.category === category);
    }

    pools.sort((a, b) => {
      const mul = order === 'desc' ? -1 : 1;
      return (a[sortBy] - b[sortBy]) * mul;
    });

    const paginated = pools.slice(Number(offset), Number(offset) + Number(limit));

    res.json({
      success: true,
      data: {
        pools: paginated,
        total: pools.length,
        offset: Number(offset),
        limit: Number(limit),
      },
      meta: {
        totalTVL: pools.reduce((s, p) => s + p.tvl, 0),
        totalVolume24h: pools.reduce((s, p) => s + p.volume24h, 0),
        highestAPY: Math.max(...pools.map(p => p.apy)),
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/pools/:id
 * Get pool details
 */
router.get('/:id', [
  param('id').isInt({ min: 1 }),
], validateRequest, async (req, res) => {
  try {
    const pool = mockPools.find(p => p.id === parseInt(req.params.id));
    if (!pool) return res.status(404).json({ success: false, error: 'Pool not found' });
    res.json({ success: true, data: pool });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/pools/:id/chart
 * Get pool price/TVL history for charting
 */
router.get('/:id/chart', [
  param('id').isInt({ min: 1 }),
  query('period').optional().isIn(['1d', '7d', '30d', '90d', '1y']),
], validateRequest, async (req, res) => {
  try {
    const period = req.query.period || '7d';
    const points = period === '1d' ? 24 : period === '7d' ? 7 * 24 : 30;
    const now = Date.now();

    // Generate mock chart data
    let tvl = 423_000_000;
    const data = Array.from({ length: points }, (_, i) => {
      tvl += (Math.random() - 0.45) * tvl * 0.02;
      return {
        timestamp: now - (points - i) * 3600 * 1000,
        tvl: Math.round(tvl),
        volume: Math.round(Math.random() * 5_000_000 + 2_000_000),
        apy: 18.4 + (Math.random() - 0.5) * 2,
      };
    });

    res.json({ success: true, data, period });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/pools/user/:address/positions
 * Get user's LP positions
 */
router.get('/user/:address/positions', [
  param('address').isEthereumAddress(),
], validateRequest, authenticate, async (req, res) => {
  try {
    // In production: query contract events or indexed DB
    const mockPositions = [
      { poolId: 1, pair: 'BTC/USDC', deposited: 45200, currentValue: 52840, lpTokens: '1234567890000000000', apy: 18.4, earned: 892, depositedAt: Date.now() - 34 * 86400 * 1000 },
      { poolId: 2, pair: 'ETH/USDC', deposited: 28000, currentValue: 31920, lpTokens: '987654321000000000', apy: 22.1, earned: 543, depositedAt: Date.now() - 21 * 86400 * 1000 },
    ];

    const totalValue = mockPositions.reduce((s, p) => s + p.currentValue, 0);
    const totalEarned = mockPositions.reduce((s, p) => s + p.earned, 0);

    res.json({
      success: true,
      data: {
        positions: mockPositions,
        summary: {
          totalDeposited: mockPositions.reduce((s, p) => s + p.deposited, 0),
          totalValue,
          totalEarned,
          pnl: totalValue - mockPositions.reduce((s, p) => s + p.deposited, 0),
          pnlPercent: ((totalValue / mockPositions.reduce((s, p) => s + p.deposited, 0)) - 1) * 100,
        },
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/pools/:id/estimate
 * Estimate returns for a deposit
 */
router.post('/:id/estimate', [
  param('id').isInt({ min: 1 }),
  body('amount').isFloat({ min: 0.01 }),
  body('days').optional().isInt({ min: 1, max: 365 }),
], validateRequest, async (req, res) => {
  try {
    const pool = mockPools.find(p => p.id === parseInt(req.params.id));
    if (!pool) return res.status(404).json({ success: false, error: 'Pool not found' });

    const { amount, days = 30 } = req.body;
    const dailyRate = pool.apy / 365 / 100;
    const estimatedEarnings = amount * dailyRate * days;
    const poolShare = amount / pool.tvl;

    res.json({
      success: true,
      data: {
        amount,
        days,
        estimatedEarnings: estimatedEarnings.toFixed(2),
        estimatedDailyEarnings: (amount * dailyRate).toFixed(4),
        poolShare: (poolShare * 100).toFixed(6),
        apy: pool.apy,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
