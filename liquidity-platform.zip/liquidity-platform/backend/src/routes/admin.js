const express = require('express');
const router = express.Router();
const { requireRole } = require('../middleware/auth');

// All routes require ADMIN role
router.use(requireRole('admin'));

// GET /api/admin/overview
router.get('/overview', (req, res) => {
  res.json({
    success: true,
    data: {
      tvl: 2_400_000_000,
      volume24h: 890_000_000,
      fees24h: 267_000,
      users: 12847,
      activePools: 44,
      pendingBuyback: 124_800,
      lastBuyback: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
  });
});

// GET /api/admin/pools
router.get('/pools', (req, res) => {
  res.json({
    success: true,
    data: [
      { id: 1, pair: 'BTC/USDC', tvl: 423_000_000, apy: 18.4, active: true, fee: 0.3 },
      { id: 2, pair: 'ETH/USDC', tvl: 312_000_000, apy: 22.1, active: true, fee: 0.3 },
    ],
  });
});

// PATCH /api/admin/pools/:id
router.patch('/pools/:id', (req, res) => {
  res.json({ success: true, message: `Pool ${req.params.id} updated` });
});

// POST /api/admin/buyback/trigger
router.post('/buyback/trigger', (req, res) => {
  res.json({ success: true, message: 'Buyback triggered. TX pending...' });
});

// GET /api/admin/users
router.get('/users', (req, res) => {
  res.json({ success: true, data: [], total: 12847 });
});

module.exports = router;
