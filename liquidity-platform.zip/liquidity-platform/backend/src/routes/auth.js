const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { ethers } = require('ethers');

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-in-production';
const JWT_EXPIRES = '7d';

// GET /api/auth/nonce/:address — get a nonce to sign
const nonces = new Map();

router.get('/nonce/:address', (req, res) => {
  const { address } = req.params;
  if (!ethers.isAddress(address)) {
    return res.status(400).json({ error: 'Invalid address' });
  }
  const nonce = `Sign this message to authenticate with LiquidityX.\n\nNonce: ${Math.random().toString(36).slice(2)}\nTimestamp: ${Date.now()}`;
  nonces.set(address.toLowerCase(), nonce);
  res.json({ success: true, nonce });
});

// POST /api/auth/verify — verify signature and issue JWT
router.post('/verify', async (req, res) => {
  try {
    const { address, signature } = req.body;
    if (!address || !signature) return res.status(400).json({ error: 'Missing fields' });

    const nonce = nonces.get(address.toLowerCase());
    if (!nonce) return res.status(400).json({ error: 'No nonce found. Request a nonce first.' });

    const recovered = ethers.verifyMessage(nonce, signature);
    if (recovered.toLowerCase() !== address.toLowerCase()) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    nonces.delete(address.toLowerCase());

    const token = jwt.sign(
      { address: address.toLowerCase(), role: 'user' },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES }
    );

    res.json({
      success: true,
      token,
      address: address.toLowerCase(),
      expiresIn: JWT_EXPIRES,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
