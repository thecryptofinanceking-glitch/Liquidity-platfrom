const express = require('express');
const router = express.Router();

// GET /api/analytics/overview
router.get('/overview', (req, res) => {
  res.json({
    success: true,
    data: {
      tvl: { value: 2_400_000_000, change24h: 5.2, change7d: 14.2 },
      volume24h: { value: 890_000_000, change24h: 12.3 },
      fees24h: { value: 267_000, change24h: 8.7 },
      users: { total: 12847, active24h: 847, new24h: 43 },
      pools: { total: 47, active: 44 },
      lqxPrice: { value: 1.24, change24h: 12.3 },
      marketCap: { value: 9_800_000, change24h: 12.3 },
    },
  });
});

// GET /api/analytics/tvl-history
router.get('/tvl-history', (req, res) => {
  const days = parseInt(req.query.days) || 30;
  let tvl = 2_000_000_000;
  const data = Array.from({ length: days }, (_, i) => {
    tvl += (Math.random() - 0.45) * tvl * 0.03;
    return {
      date: new Date(Date.now() - (days - i) * 86400000).toISOString().split('T')[0],
      tvl: Math.round(tvl),
    };
  });
  res.json({ success: true, data });
});

// GET /api/analytics/volume-history
router.get('/volume-history', (req, res) => {
  const days = parseInt(req.query.days) || 30;
  const data = Array.from({ length: days }, (_, i) => ({
    date: new Date(Date.now() - (days - i) * 86400000).toISOString().split('T')[0],
    volume: Math.round(Math.random() * 1_000_000_000 + 400_000_000),
  }));
  res.json({ success: true, data });
});

// GET /api/analytics/fees
router.get('/fees', (req, res) => {
  const days = parseInt(req.query.days) || 30;
  const data = Array.from({ length: days }, (_, i) => ({
    date: new Date(Date.now() - (days - i) * 86400000).toISOString().split('T')[0],
    fees: Math.round(Math.random() * 400_000 + 100_000),
    buyback: Math.round(Math.random() * 160_000 + 40_000),
    stakers: Math.round(Math.random() * 240_000 + 60_000),
  }));
  res.json({ success: true, data });
});

module.exports = router;
