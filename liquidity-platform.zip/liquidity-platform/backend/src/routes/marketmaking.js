const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { validateRequest } = require('../middleware/validate');

// POST /api/market-making/apply
router.post('/apply', [
  body('tokenName').notEmpty().isLength({ min: 2, max: 100 }),
  body('tokenSymbol').notEmpty().isLength({ min: 2, max: 10 }),
  body('exchange').notEmpty(),
  body('liquidityRequired').notEmpty(),
  body('budget').notEmpty(),
  body('email').isEmail().normalizeEmail(),
  body('tge').optional().isBoolean(),
  body('message').optional().isLength({ max: 2000 }),
], validateRequest, async (req, res) => {
  try {
    const application = {
      id: `MM-${Date.now()}`,
      ...req.body,
      status: 'pending',
      submittedAt: new Date().toISOString(),
    };

    // In production: save to DB + notify team via Slack/email
    console.log('New market making application:', application);

    res.json({
      success: true,
      data: {
        applicationId: application.id,
        message: 'Application received. Our team will contact you within 24 hours.',
        estimatedReview: '1-2 business days',
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/market-making/packages
router.get('/packages', (req, res) => {
  res.json({
    success: true,
    data: [
      { id: 'starter', name: 'Starter', price: 8000, liquidity: 500000, pairs: 2, exchanges: 1 },
      { id: 'pro', name: 'Professional', price: 25000, liquidity: 2000000, pairs: 5, exchanges: 3 },
      { id: 'institutional', name: 'Institutional', price: null, liquidity: 20000000, pairs: -1, exchanges: -1 },
    ],
  });
});

module.exports = router;
