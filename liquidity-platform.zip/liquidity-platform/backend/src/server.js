require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const cron = require('node-cron');

const poolsRouter = require('./routes/pools');
const stakingRouter = require('./routes/staking');
const buybackRouter = require('./routes/buyback');
const marketMakingRouter = require('./routes/marketmaking');
const analyticsRouter = require('./routes/analytics');
const leaderboardRouter = require('./routes/leaderboard');
const referralRouter = require('./routes/referral');
const adminRouter = require('./routes/admin');
const authRouter = require('./routes/auth');

const { errorHandler } = require('./middleware/error');
const { authenticate } = require('./middleware/auth');
const { setupWebSocket } = require('./services/websocket');
const { startBuybackScheduler } = require('./services/scheduler');
const logger = require('./utils/logger');

const app = express();
const PORT = process.env.PORT || 4000;

// ─── Security Middleware ───────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});
const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,  // 1 minute
  max: 60,
});

app.use(limiter);
app.use('/api', apiLimiter);

// ─── Body Parsing ──────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));

// ─── Health check ──────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    network: process.env.CHAIN_ID || '42161',
  });
});

// ─── Public routes ─────────────────────────────────────────────────────────
app.use('/api/auth', authRouter);
app.use('/api/pools', poolsRouter);
app.use('/api/buyback', buybackRouter);
app.use('/api/analytics', analyticsRouter);
app.use('/api/leaderboard', leaderboardRouter);

// ─── Protected routes ──────────────────────────────────────────────────────
app.use('/api/staking', authenticate, stakingRouter);
app.use('/api/market-making', marketMakingRouter);
app.use('/api/referral', authenticate, referralRouter);

// ─── Admin routes ──────────────────────────────────────────────────────────
app.use('/api/admin', authenticate, adminRouter);

// ─── Error Handler ─────────────────────────────────────────────────────────
app.use(errorHandler);

// ─── 404 handler ───────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// ─── Start Server ──────────────────────────────────────────────────────────
const server = app.listen(PORT, () => {
  logger.info(`🚀 LiquidityX API running on port ${PORT}`);
  logger.info(`🌐 Network: ${process.env.CHAIN_ID || '42161'} (Arbitrum)`);
  logger.info(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});

// ─── WebSocket for real-time price feeds ───────────────────────────────────
setupWebSocket(server);

// ─── Scheduled tasks ───────────────────────────────────────────────────────
if (process.env.ENABLE_SCHEDULER === 'true') {
  startBuybackScheduler();
  logger.info('⏰ Buyback scheduler started');
}

// Weekly buyback check (Sundays at midnight UTC)
cron.schedule('0 0 * * 0', async () => {
  logger.info('🔥 Executing scheduled weekly buyback check...');
  const { checkAndExecuteBuyback } = require('./services/buyback');
  await checkAndExecuteBuyback();
});

// Hourly analytics snapshot
cron.schedule('0 * * * *', async () => {
  const { snapshotAnalytics } = require('./services/analytics');
  await snapshotAnalytics();
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

module.exports = app;
