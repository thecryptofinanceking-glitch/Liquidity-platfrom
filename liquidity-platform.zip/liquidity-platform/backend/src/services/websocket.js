const { WebSocketServer } = require('ws');

const subscribers = new Map();

function setupWebSocket(server) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const clientId = Date.now().toString();
    console.log(`[WS] Client connected: ${clientId}`);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'subscribe') {
          subscribers.set(clientId, { ws, channels: msg.channels || [] });
          ws.send(JSON.stringify({ type: 'subscribed', channels: msg.channels }));
        }
      } catch {}
    });

    ws.on('close', () => {
      subscribers.delete(clientId);
      console.log(`[WS] Client disconnected: ${clientId}`);
    });

    // Send initial ping
    ws.send(JSON.stringify({ type: 'connected', clientId }));
  });

  // Broadcast real-time price updates
  setInterval(() => {
    const prices = {
      type: 'prices',
      data: {
        'BTC/USDC': (67000 + Math.random() * 2000 - 1000).toFixed(2),
        'ETH/USDC': (3500 + Math.random() * 200 - 100).toFixed(2),
        'ARB/USDC': (1.2 + Math.random() * 0.1 - 0.05).toFixed(4),
        tvl: (2_400_000_000 + Math.random() * 10_000_000).toFixed(0),
      },
      timestamp: Date.now(),
    };

    subscribers.forEach(({ ws, channels }) => {
      if (ws.readyState === 1 && (channels.includes('prices') || channels.length === 0)) {
        ws.send(JSON.stringify(prices));
      }
    });
  }, 3000);

  return wss;
}

module.exports = { setupWebSocket };
